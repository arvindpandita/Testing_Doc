# Databricks notebook source
class read_excel(baseReader):
    """
    Reads and loads excel files
    
    Attributes
    ------------
    checkHeader: boolean
        check if the csv file has a header
    inputFilePath: str
        input file location
    enableFileTracker: boolean
        allows to turn off the file tracker, enabling the reader to read previously logged files
        
    Methods
    --------
    read: reads and loads all avaliable csv files
    
    """
    
    def __init__(self, **kw):
        """
        parameters
        ----------
            
        """
        super(read_excel, self).__init__(**kw)
    
    def read(self
             ,inputFilePath 
             ,schema
             ,sheetName
             ,data_address
             ,checkDelimiter=","
             ,checkHeader = False
             ,enableFileTracker = False
            ):
        """
        parameters
        ----------
        header: boolean
            check if the csv file has a header
            
        """

        combined_df = None

        # get unprocessed files list
        if enableFileTracker:
            inputFilePath = self.fileTracker(inputFilePath)

            if not inputFilePath:
                # If no files, return an empty DataFrame with the given schema
                return spark.createDataFrame([], schema)
            else:

                for file_path in inputFilePath:
            
                    # read all avaliable files   
                    df = (spark.read
                        .format("com.crealytics.spark.excel")
                        .option("dataAddress", data_address)
                        .option("sheetName", sheetName)
                        .option("delimiter", checkDelimiter)
                        .option("header", "True")
                        .load(file_path) 
                        )
                    
                    df = df.withColumn("filepath", lit(file_path)).withColumn("filename", lit(element_at(split(file_path, "/"),-1)))
                    
                    # Combine with the accumulated DataFrame
                    if combined_df is None:
                        combined_df = df
                    else:
                        combined_df = combined_df.unionByName(df)

                # trim whitespace in all columns
                # combined_df = self.remove_whitespace_from_column_names(combined_df)

                # add metadata
                # combined_df = self.getFileMetadata(combined_df)
                

                return combined_df
        

        else:
            # Get all files in directory
            inputFilePath = [f.path for f in dbutils.fs.ls(inputFilePath)]
            
            print(inputFilePath)

            for file_path in inputFilePath:
            
                # read all avaliable files   
                df = (spark.read
                    .format("com.crealytics.spark.excel")
                    .option("dataAddress", data_address)
                    .option("sheetName", sheetName)
                    .option("delimiter", checkDelimiter)
                    .option("header", "True")
                    .load(file_path) 
                    )
                
                # Combine with the accumulated DataFrame
                if combined_df is None:
                    combined_df = df
                else:
                    combined_df = combined_df.unionByName(df)
        
            # trim whitespace in all columns
                
            # add metadata
            combined_df = self.getFileMetadata(combined_df)

            return combined_df
