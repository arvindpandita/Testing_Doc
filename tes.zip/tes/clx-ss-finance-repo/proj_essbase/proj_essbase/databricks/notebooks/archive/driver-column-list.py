# Databricks notebook source
column_definition_driver_p_l = [
  {"columnName":"Scenario 1", "dataType":"string"}
  ,{"columnName":"Segment", "dataType":"string"}
  ,{"columnName":"Division", "dataType":"string"}
  ,{"columnName":"SBU", "dataType":"string"}
  ,{"columnName":"Year", "dataType":"string"}
  ,{"columnName":"Quarter", "dataType":"string"}
  ,{"columnName":"Scenario", "dataType":"string"}
  ,{"columnName":"P&L", "dataType":"string"}
  ,{"columnName":"Category", "dataType":"string"}
  ,{"columnName":"Account", "dataType":"string"}
  ,{"columnName":"Sub - Account", "dataType":"string"}
  ,{"columnName":"Driver", "dataType":"string"}
  ,{"columnName":"Drill Down Type", "dataType":"string"} 
  ,{"columnName":"Number Type", "dataType":"string"} 
  ,{"columnName":"Look up #", "dataType":"string"} 
  ,{"columnName":"Name Manager", "dataType":"string"}
  ,{"columnName":"Scenario Manager", "dataType":"string"} 
  ,{"columnName":"Measure (TBD)", "dataType":"float"} 
  ,{"columnName":"Prev Period NCS", "dataType":"float"} 
  ,{"columnName":"Prev Period GP", "dataType":"float"} 
  ,{"columnName":"Curr Period NCS", "dataType":"float"} 
  ,{"columnName":"Curr Period GP", "dataType":"float"} 
] 

# COMMAND ----------

column_definition_driver_bucket = [
  {"columnName":"Scenario 1", "dataType":"string"} 
  ,{"columnName":"Segment", "dataType":"string"} 
  ,{"columnName":"Division", "dataType":"string"} 
  ,{"columnName":"SBU", "dataType":"string"} 
  ,{"columnName":"Year", "dataType":"string"}
  ,{"columnName":"Quarter", "dataType":"string"}
  ,{"columnName":"Scenario", "dataType":"string"}
  ,{"columnName":"P&L", "dataType":"string"}
  ,{"columnName":"Category", "dataType":"string"}
  ,{"columnName":"Account", "dataType":"string"}
  ,{"columnName":"Sub - Account", "dataType":"string"}
  ,{"columnName":"Driver", "dataType":"string"}
  ,{"columnName":"Drill Down Type", "dataType":"string"}
  ,{"columnName":"Number Type", "dataType":"string"}
  ,{"columnName":"Look up #", "dataType":"string"}
  ,{"columnName":"Name Manager", "dataType":"string"}
  ,{"columnName":"Scenario Manager", "dataType":"string"}
  ,{"columnName":"Measure (TBD)", "dataType":"float"} 

] 

# COMMAND ----------

column_definition_driver_Volume = [ 
    {"columnName":"Scenario 1", "dataType":"string"} 
   ,{"columnName":"Segment", "dataType":"string"} 
   ,{"columnName":"Division", "dataType":"string"} 
   ,{"columnName":"SBU", "dataType":"string"}
   ,{"columnName":"Year", "dataType":"string"} 
   ,{"columnName":"Quarter", "dataType":"string"} 
   ,{"columnName":"Quarter Key", "dataType":"string"} 
   ,{"columnName":"Scenario", "dataType":"string"} 
   ,{"columnName":"P&L", "dataType":"string"} 
   ,{"columnName":"Category", "dataType":"string"} 
   ,{"columnName":"Bucket", "dataType":"string"} 
   ,{"columnName":"Market Facing Family", "dataType":"string"} 
   ,{"columnName":"Scenario Manager", "dataType":"string"} 
   ,{"columnName":"Volume", "dataType":"float"} 
   ,{"columnName":"Quarter High Volume", "dataType":"float"} 
   ,{"columnName":"Quarter High Scenario", "dataType":"string"} 
   ,{"columnName":"All Time High Volume", "dataType":"float"} 
   ,{"columnName":"All Time High Scenario", "dataType":"string"} 
   ,{"columnName":"YOY Index", "dataType":"float"}
] 

# COMMAND ----------

column_definition_driver_story = [ 

    {"columnName":"Scenario 1", "dataType":"string"} 
   ,{"columnName":"Segment", "dataType":"string"} 
   ,{"columnName":"Division", "dataType":"string"} 
   ,{"columnName":"SBU", "dataType":"string"} 
   ,{"columnName":"Year", "dataType":"string"} 
   ,{"columnName":"Quarter", "dataType":"string"} 
   ,{"columnName":"Scenario", "dataType":"string"} 
   ,{"columnName":"P&L", "dataType":"string"} 
   ,{"columnName":"Category", "dataType":"string"} 
   ,{"columnName":"Account", "dataType":"string"} 
   ,{"columnName":"Scenario Manager", "dataType":"string"}	 
   ,{"columnName":"Key Takeaway", "dataType":"string"} 

] 

# COMMAND ----------



# COMMAND ----------

column_definition_driver_exec_summary = [ 

    {"columnName":"Scenario 1", "dataType":"string"} 
   ,{"columnName":"Segment", "dataType":"string"} 
   ,{"columnName":"Division", "dataType":"string"} 
   ,{"columnName":"SBU", "dataType":"string"} 
   ,{"columnName":"Year", "dataType":"string"} 
   ,{"columnName":"Quarter", "dataType":"string"} 
   ,{"columnName":"Scenario", "dataType":"string"} 
   ,{"columnName":"Focus Area", "dataType":"string"} 
   ,{"columnName":"Sub Category", "dataType":"string"} 
   ,{"columnName":"P&L", "dataType":"string"} 
   ,{"columnName":"Brand", "dataType":"string"}	 
   ,{"columnName":"Scenario Manager ", "dataType":"string"} 
   ,{"columnName":"Metric", "dataType":"string"}	 
   ,{"columnName":"Key Takeway", "dataType":"string"} 

] 
