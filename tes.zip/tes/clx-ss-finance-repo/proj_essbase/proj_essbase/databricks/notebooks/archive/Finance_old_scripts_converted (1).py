# Databricks notebook source
from pyspark.sql.types import IntegerType
from pyspark.sql import functions as F

# COMMAND ----------

jdbcHostname = "sql-ssefin-selfserv01.database.windows.net"
jdbcPort = 1433
jdbcDatabase = "SQLDB-SSEFIN-SELFSERV01"
jdbcUsername = "sqldbadmin"
jdbcPassword = "F!nSS3SQL2021!"
jdbcDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
jdbcUrl = f"jdbc:sqlserver://{jdbcHostname}:{jdbcPort};databaseName={jdbcDatabase};user={jdbcUsername};password={jdbcPassword}"

# COMMAND ----------

df1 = spark.read.format("jdbc").option("url",jdbcUrl).option("dbtable","DWH_FINANCE.MAP_FLAG_CATEGORY").load()
df2 = spark.read.format("jdbc").option("url",jdbcUrl).option("dbtable","DWH_FINANCE.MAP_BU_CATEGORY").load()
df3 = spark.read.format("jdbc").option("url",jdbcUrl).option("dbtable","DWH_FINANCE.MAP_Material_category").load()
df4 = spark.read.format("jdbc").option("url",jdbcUrl).option("dbtable","DWH_FINANCE.BW_PRICING").load()
df5 = spark.read.format("jdbc").option("url",jdbcUrl).option("dbtable","DWH_FINANCE.BW_FINANCE_BRAND_PL_DETAILED").load()
df6 = spark.read.format("jdbc").option("url",jdbcUrl).option("dbtable","DWH_FINANCE.MATERIAL_MASTER").load()
df7 = spark.read.format("jdbc").option("url",jdbcUrl).option("dbtable","DWH_FINANCE.BW_MATERIAL_DIM").load()
df8 = spark.read.format("jdbc").option("url",jdbcUrl).option("dbtable","DWH_FINANCE.PPD_TEST").load()
df9 = spark.read.format("jdbc").option("url",jdbcUrl).option("dbtable","DWH_FINANCE.SBU").load()

# COMMAND ----------

df1.createOrReplaceTempView("DWH_FINANCE.MAP_FLAG_CATEGORY") 
df2.createOrReplaceTempView("DWH_FINANCE.MAP_BU_CATEGORY") 
df3.createOrReplaceTempView("DWH_FINANCE.MAP_MATERIAL_CATEGORY") 
df4.createOrReplaceTempView("DWH_FINANCE.BW_PRICING") 
df5.createOrReplaceTempView("DWH_FINANCE.BW_FINANCE_BRAND_PL_DETAILED")
df6.createOrReplaceTempView("DWH_FINANCE.MATERIAL_MASTER") 
df7.createOrReplaceTempView("DWH_FINANCE.BW_MATERIAL_DIM")
df8.createOrReplaceTempView("DWH_FINANCE.PPD_TEST")
df9.createOrReplaceTempView("DWH_FINANCE.SBU")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from PPD_TEST

# COMMAND ----------

# MAGIC %md
# MAGIC #### Flag Wise Total Volume Stat Cases

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT category,sub_category,pmu,flag,sum(b.volume_sc) as total_volume_sc_flag FROM MATERIAL_MASTER a join BW_FINANCE_BRAND_PL_DETAILED b on cast(a.material as int) = cast(b.Material as int)
# MAGIC where  b.version = '2BA' and b.profit_center = '21300' 
# MAGIC group by category,sub_category,pmu,flag
# MAGIC order by category,sub_category,pmu,flag

# COMMAND ----------

# MAGIC %md
# MAGIC #### Material Wise Total Volume Stat Cases

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT a.material,a.category,a.sub_category,a.pmu,a.flag, sum(b.volume_sc) as total_volume_sc_material FROM MATERIAL_MASTER a join BW_FINANCE_BRAND_PL_DETAILED b
# MAGIC on cast(a.material as int) = cast(b.Material as int)
# MAGIC where  b.version = '2BA' and b.profit_center = '21300' 
# MAGIC group by a.material,a.category,a.sub_category,a.pmu,a.flag
# MAGIC order by cast(a.material as int),a.category,a.sub_category,a.pmu,a.flag

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Final Total amount calculation

# COMMAND ----------

df10 = spark.sql(
"""SELECT p.bu,p.material,p.account,p.category,p.sub_category,p.pmu,p.allocation_flag,q.flag,p.amount,q.total_volume_sc_flag,              (p.amount/q.total_volume_sc_flag) as amount_per_volume, p.total_volume_sc_material,
    (p.amount/q.total_volume_sc_flag)*p.total_volume_sc_material as total_amount from
(
SELECT  x.bu,y.material,x.account,x.category,y.sub_category,y.pmu,x.allocation_flag, amount, sum(total_volume_sc_material) as total_volume_sc_material from 
(select bu,account,category,allocation_flag,sum(amount_ppl) as amount from PPD_TEST group by account,category,allocation_flag,bu
) x 
left join 
(
SELECT a.material,a.category,a.sub_category,a.pmu,a.flag, sum(b.volume_sc) as total_volume_sc_material FROM MATERIAL_MASTER a join BW_FINANCE_BRAND_PL_DETAILED b
on cast(a.material as int) = cast(b.Material as int)
where  b.version = '2BA' and b.profit_center = '21300' 
group by a.material,a.category,a.sub_category,a.pmu,a.flag
order by cast(a.material as int),a.category,a.sub_category,a.pmu,a.flag
) y
on  lower(x.allocation_flag) = Case When x.category = 'Category' then lower(y.category)
                                    When x.category = 'Sub_Category' then lower(y.sub_category)
                                    When x.category = 'PMU' then lower(y.pmu)
                                    When x.category = 'Flag' then lower(y.flag)
                               End
group by x.account,x.category,x.allocation_flag,x.amount,y.material,y.sub_category,y.pmu,x.bu
order by x.account,x.category,total_volume_sc_material,x.allocation_flag,x.amount,cast(y.material as int),y.sub_category,y.pmu
)p
left join
(
SELECT category,sub_category,pmu,flag,sum(b.volume_sc) as total_volume_sc_flag FROM MATERIAL_MASTER a join BW_FINANCE_BRAND_PL_DETAILED b on cast(a.material as int) = cast(b.Material as int)
where  b.version = '2BA' and b.profit_center = '21300' 
group by category,sub_category,pmu,flag
order by category,sub_category,pmu,flag
)q
on  lower(p.allocation_flag) = Case When p.category = 'Category' then lower(q.category)
                                    When p.category = 'Sub_Category' then lower(q.sub_category)
                                    When p.category = 'PMU' then lower(q.pmu)
                                    When p.category = 'Flag' then lower(q.flag)                                    
                                    End
 and  p.sub_category = q.sub_category    
 and  p.pmu= q.pmu
 order by cast(p.material as int),p.account,p.category,p.total_volume_sc_material,p.allocation_flag,p.amount,p.sub_category,p.pmu,q.flag
 """)
display(df10)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Joining the Totals with Material Master 

# COMMAND ----------

df11 = df10.groupBy('material','account').pivot('account').sum('total_amount').select('material','DND','SWP Spend','Usage').groupBy('material').sum('DND','SWP Spend','Usage').select(F.col('material'),F.col('sum(DND)').alias('DND'),F.col('sum(SWP Spend)').alias('SWP Spend'),F.col('sum(Usage)').alias('Usage')).orderBy(F.col('MATERIAL').cast(IntegerType()))
display(df11)

# COMMAND ----------

df12 = df6.alias('a').join(df11.alias('b'), F.col('a.material') == F.col('b.material'))
display(df12)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Joining with Material Master in combination

# COMMAND ----------

df13 = df10.groupBy('material','account','category','sub_category','pmu','flag','bu').pivot('account').sum('total_amount').select('material','account','category','sub_category','pmu','flag','bu','DND','SWP Spend','Usage').groupBy('material','category','sub_category','pmu','flag','bu').sum('DND','SWP Spend','Usage').select('material','bu','category','sub_category','pmu','flag',F.col('sum(DND)').alias('DND'),F.col('sum(SWP Spend)').alias('SWP Spend'),F.col('sum(Usage)').alias('Usage')).orderBy(F.col('MATERIAL').cast(IntegerType()),'category','sub_category','pmu','flag')
display(df13)

# COMMAND ----------

# Material Mater Table
display(df6.orderBy(F.col('MATERIAL').cast(IntegerType())))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Normal Join

# COMMAND ----------

df14 = df6.alias('a').join(df13.alias('b'), (F.col('a.material') == F.col('b.material'))&(F.col('a.sub_category') == F.col('b.sub_category'))&(F.col('a.pmu') == F.col('b.pmu'))&
    (F.col('a.flag') == F.col('b.flag'))&(F.lower(F.col('a.brand_name')) == F.lower(F.col('b.bu')))).distinct().orderBy(F.col('a.MATERIAL').cast(IntegerType()),'a.category','a.sub_category','a.pmu','a.flag')
#&(F.col('a.brand_name') == F.col('b.bu')))#&(F.col('a.category') == F.col('b.category'))))
display(df14)

# COMMAND ----------

df15 = df14.select(
 'a.MATERIAL',
 'a.MATERIAL_NAME',
 'a.BRAND',
 'a.BRAND_NAME',
 'a.PURPOSE',
 'a.PURPOSE_NAME',
 'a.TYPE',
 'a.TYPE_NAME',
 'a.PACK_SIZE',
 'a.PACK_SIZE_NAME',
 'a.PMU',
 'a.CATEGORY',
 'a.SUB_CATEGORY',
 'a.UPC',
 'a.CT',
 'a.PRICING',
 'a.Amount',
 'a.STAT_FACTOR',
 'a.STAT_BASIS',
 'a.FLAG',
 'b.DND',
 'b.SWP Spend',
 'b.Usage').groupBy(
 'a.MATERIAL',
 'a.MATERIAL_NAME',
 'a.BRAND',
 'a.BRAND_NAME',
 'a.PURPOSE',
 'a.PURPOSE_NAME',
 'a.TYPE',
 'a.TYPE_NAME',
 'a.PACK_SIZE',
 'a.PACK_SIZE_NAME',
 'a.PMU',
 'a.CATEGORY',
 'a.SUB_CATEGORY',
 'a.UPC',
 'a.CT',
 'a.PRICING',
 'a.Amount',
 'a.STAT_FACTOR',
 'a.STAT_BASIS',
 'a.FLAG').sum( 
  'b.DND',
 'b.SWP Spend',
 'b.Usage').orderBy(F.col('a.MATERIAL').cast(IntegerType()),'a.category','a.sub_category','a.pmu','a.flag')
display(df15)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Left Join

# COMMAND ----------

df16 = df6.alias('a').join(df13.alias('b'), (F.col('a.material') == F.col('b.material'))&(F.col('a.sub_category') == F.col('b.sub_category'))&(F.col('a.pmu') == F.col('b.pmu'))&
    (F.col('a.flag') == F.col('b.flag'))&(F.lower(F.col('a.brand_name')) == F.lower(F.col('b.bu'))),"left").distinct().orderBy(F.col('a.MATERIAL').cast(IntegerType()),'a.category','a.sub_category','a.pmu','a.flag')
#&(F.col('a.brand_name') == F.col('b.bu')))#&(F.col('a.category') == F.col('b.category'))))
display(df16)

# COMMAND ----------

df17 = df16.select(
 'a.MATERIAL',
 'a.MATERIAL_NAME',
 'a.BRAND',
 'a.BRAND_NAME',
 'a.PURPOSE',
 'a.PURPOSE_NAME',
 'a.TYPE',
 'a.TYPE_NAME',
 'a.PACK_SIZE',
 'a.PACK_SIZE_NAME',
 'a.PMU',
 'a.CATEGORY',
 'a.SUB_CATEGORY',
 'a.UPC',
 'a.CT',
 'a.PRICING',
 'a.Amount',
 'a.STAT_FACTOR',
 'a.STAT_BASIS',
 'a.FLAG',
 'b.DND',
 'b.SWP Spend',
 'b.Usage').groupBy(
 'a.MATERIAL',
 'a.MATERIAL_NAME',
 'a.BRAND',
 'a.BRAND_NAME',
 'a.PURPOSE',
 'a.PURPOSE_NAME',
 'a.TYPE',
 'a.TYPE_NAME',
 'a.PACK_SIZE',
 'a.PACK_SIZE_NAME',
 'a.PMU',
 'a.CATEGORY',
 'a.SUB_CATEGORY',
 'a.UPC',
 'a.CT',
 'a.PRICING',
 'a.Amount',
 'a.STAT_FACTOR',
 'a.STAT_BASIS',
 'a.FLAG').sum( 
  'b.DND',
 'b.SWP Spend',
 'b.Usage').orderBy(F.col('a.MATERIAL').cast(IntegerType()),'a.category','a.sub_category','a.pmu','a.flag')
display(df17)

# COMMAND ----------

# For Validation
display(df10.groupBy('material','account','category','sub_category','pmu','flag','bu').sum('total_amount').orderBy(F.col('MATERIAL').cast(IntegerType()),'account','category','sub_category','pmu','flag'))
