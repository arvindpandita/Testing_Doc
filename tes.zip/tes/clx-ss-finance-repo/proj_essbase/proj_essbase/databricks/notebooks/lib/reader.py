# Databricks notebook source
import os
from urllib.parse import unquote
from datetime import datetime
from pyspark.sql.functions import col, lit, input_file_name, current_timestamp, element_at, split, to_timestamp, to_date

# COMMAND ----------

class baseReader(object):
    """
    Reads and loads files
    
    Attributes
    ------------
        
    Methods
    --------
    fileTracker : 
    getFileMetadata : 
    trimDataframe : 
    
    """
    
    def __init__(self
                 ,processDatetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                ):
        """
        parameters
        ----------
            
        """
        self.processDatetime = processDatetime
    

    def fileTracker(self, input_path, log_table='audit.file_tracker_log'):

        # Query the log table to get processed files
        processed_files_df = spark.table(log_table).select("filepath")
        processed_files = [unquote(row.filepath) for row in processed_files_df.collect()]

        # Get all files in directory and decode URLs
        all_files = [unquote(f.path) for f in dbutils.fs.ls(input_path)]

        # Filter out processed files
        unprocessed_files = [f for f in all_files if f not in processed_files]

        return unprocessed_files
    
    def trimDataframe(self):
        return 
    
    def remove_whitespace_from_column_names(self, df):
        """
        Rename all columns in a DataFrame by removing white spaces.

        :param df: Spark DataFrame with column names that might contain white spaces.
        :return: DataFrame with white spaces removed from column names.
        
        """
        for col_name in df.columns:
            new_col_name = col_name.replace("\s*", "") 
            df = df.withColumnRenamed(col_name, new_col_name)
        return df

    def getFileMetadata(self, df):
        
        df = (df
            .withColumn("filepath", lit(input_file_name()))
            .withColumn("filename", lit(element_at(split(input_file_name(), "/"),-1)))
            .withColumn("processdatetime", to_timestamp(lit(self.processDatetime)))
        )

        return df

    def read_file_with_path(self
                            , file_path
                            , file_format
                            , data_address
                            , sheetName
                            , checkDelimiter
                            , checkHeader
                            , schema):
        
        #Switch to read file base on the file format
        if file_format == "csv":
            pass
        elif file_format == "excel":
            df = (spark.read
                .format("com.crealytics.spark.excel")
                .option("dataAddress", data_address)
                .option("sheetName", sheetName)
                .option("delimiter", checkDelimiter)
                .option("header", checkHeader)
                .option("inferSchema", "false")
                .option("treatEmptyValuesAsNulls", "true")
                .schema(schema)
                .load(file_path)
                )
        else:
            pass

        # Add metadata to dataframe
        
        df = (df
            .withColumn("filepath", lit(file_path))
            .withColumn("filename", lit(element_at(split(col("filepath"), "/"),-1)))
            .withColumn("processdatetime", to_timestamp(lit(self.processDatetime)))
        )
                    
        return df
    
    def string_to_bool(self, input_string):
        """
        The input string to convert. Assumes "False" represents False, and anything else represents True.
        """
        return not input_string == "False"



# COMMAND ----------

class read_csv(baseReader):
    """
    Reads and loads csv files
    
    Attributes
    ------------
    checkHeader: boolean
        check if the csv file has a header
    inputFilePath: str
        input file location
    enableFileTracker: boolean
        allows to turn off the file tracker, enabling the reader to read previously logged files
        
    Methods
    --------
    read: reads and loads all avaliable csv files
    
    """
    
    def __init__(self, **kw):
        """
        parameters
        ----------
            
        """
        super(read_csv, self).__init__(**kw)
    
    def read(self
             ,inputFilePath 
             ,schema
             ,checkDelimiter=","
             ,checkHeader = False
             ,enableFileTracker = "False"
            ):
        """
        parameters
        ----------
        header: boolean
            check if the csv file has a header
            
        """

        enableFileTracker = self.string_to_bool(enableFileTracker)

        print(enableFileTracker)

        # get unprocessed files list
        if enableFileTracker:
            inputFilePath = self.fileTracker(inputFilePath)

            if not inputFilePath:
                # If no files, return an empty DataFrame with the given schema
                return spark.createDataFrame([], schema)

        # read all avaliable files
        df = (spark.read
              .format("csv")
              .option("delimiter", checkDelimiter)
              .option("header", checkHeader)
              .load(inputFilePath)
             )
        
        # trim whitespace in all columns
            
        # add metadata
        df = self.getFileMetadata(df)

        return df

# COMMAND ----------

class read_excel(baseReader):
    """
    Reads and loads excel files
    
    Attributes
    ------------
    checkHeader: boolean
        check if the csv file has a header
    inputFilePath: str
        input file location
    enableFileTracker: boolean
        allows to turn off the file tracker, enabling the reader to read previously logged files
        
    Methods
    --------
    read: reads and loads all avaliable csv files
    
    """
    
    def __init__(self, **kw):
        """
        parameters
        ----------
            
        """
        super(read_excel, self).__init__(**kw)
    
    def read(self
             ,inputFilePath 
             ,schema
             ,sheetName
             ,data_address
             ,checkDelimiter=","
             ,checkHeader = False
             ,enableFileTracker = False
            ):
        """
        parameters
        ----------
        header: boolean
            check if the excel file has a header
            
        """

        combined_df = None
        file_format = "excel"

        enableFileTracker = self.string_to_bool(enableFileTracker)

        # get unprocessed files list
        if enableFileTracker:

            file_paths = self.fileTracker(inputFilePath)

            if not file_paths:
                # If no files, return an empty DataFrame with the given schema
                return spark.createDataFrame([], schema)
            else:

                # Read the first file to initialize the DataFrame
                combined_df = self.read_file_with_path(file_paths[0]
                                                    , file_format
                                                    , data_address
                                                    , sheetName
                                                    , checkDelimiter 
                                                    , checkHeader
                                                    , schema )
                
                # Union the rest of the files
                for file_path in file_paths[1:]:
                    df = self.read_file_with_path(file_path
                                                , file_format
                                                , data_address
                                                , sheetName
                                                , checkDelimiter
                                                , checkHeader
                                                , schema)
                    
                    combined_df = combined_df.unionByName(df)        

        else:
            # Get all files in directory
            file_paths = [f.path for f in dbutils.fs.ls(inputFilePath)]

            # Read the first file to initialize the DataFrame
            combined_df = self.read_file_with_path(file_paths[0]
                                            , file_format
                                            , data_address
                                            , sheetName
                                            , checkDelimiter
                                            , checkHeader
                                            , schema
                                        )
            
            # Union the rest of the files
            for file_path in file_paths[1:]:
                df = self.read_file_with_path(file_path
                                            , file_format
                                            , data_address
                                            , sheetName
                                            , checkDelimiter
                                            , checkHeader
                                            , schema
                                        )
                    
                combined_df = combined_df.unionByName(df)


        # trim whilespaces from column names
        combined_df = self.remove_whitespace_from_column_names(combined_df)

        return combined_df

# COMMAND ----------

class read_sql(baseReader):
    def __init__(self):
        """
        Initializes the read_sql instance with database connection details.

        Parameters:

        """
        self.jdbcUrl = f"jdbc:sqlserver://sql-ssefin-selfserv01.database.windows.net:1433;database=SQLDB-SSEFIN-SELFSERV01;"
        self.connectionProperties = {
            "user": "SSEDATA_RW",
            "password": dbutils.secrets.get(scope="KV-SSE-SCOPE", key="KV-SSEDATA"),
            "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
        }

    def read(self, table_name):
        """
        Reads a table from the SQL database into a Spark DataFrame.

        Parameters:
        table_name (str): Name of the table to read

        Returns:
        pyspark.sql.DataFrame: DataFrame representing the SQL table
        """
        return spark.read.jdbc(url=self.jdbcUrl, table=table_name, properties=self.connectionProperties)

