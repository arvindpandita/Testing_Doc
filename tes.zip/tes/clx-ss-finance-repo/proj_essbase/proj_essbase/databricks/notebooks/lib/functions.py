# Databricks notebook source
import re
import json
import decimal
from pyspark.sql import DataFrame
from functools import reduce
from datetime import date, datetime
from pyspark.sql.types import StringType, DoubleType
from pyspark.sql.functions import date_format, to_utc_timestamp, to_date, to_timestamp, when, sha2, concat_ws, input_file_name, count, col, max, regexp_replace

# COMMAND ----------

# MAGIC %run ./logger

# COMMAND ----------

# MAGIC %run ./exception

# COMMAND ----------

def getColumnsList(columnDefinitons):
    # creating list of columns
    col_list = []
    for columndef in columnDefinitons:
        col_list.append(columndef.get("columnName"))
    return col_list
    
def replaceEmptyValues(df, column_list):
    
    # replace empty values to None values for all columns
    df2= (df
          .select([when(col(c)=="",None).otherwise(col(c)).alias(c) for c in column_list])
         )
    
    return df2
        
def applyColumnDataType(df, columnDefinitons):
    
    for columndef in columnDefinitons:
        columnName = columndef.get("columnName")
        columnDatatype = columndef.get("dataType")
        dateformat = columndef.get("format")
        
        if columnDatatype == "date":
            
            df = (df.withColumn(
                        columnName
                        ,to_date(col(columnName), dateformat))
                 )
                  
        if columnDatatype == "timestamp":
            
            df = (df.withColumn(
                        columnName
                        ,to_utc_timestamp(to_timestamp(col(columnName), dateformat), "UTC"))
                 )
            
        else:
            
            df = (df.withColumn(
                        columnName,
                        df[columnName].cast(columnDatatype))
                 )
    return df

# COMMAND ----------

def addColumnDefintions(df, columnDefinitons):
    
    # replace empty values to None values for all columns
    column_list = getColumnsList(columnDefinitons)
    
    df = replaceEmptyValues(df, column_list)

    # apply datatypes 
    df = applyColumnDataType(df, columnDefinitons)
        
    return df

# COMMAND ----------

def columnRename(df, columnDict):
    
    df = (df
          .select([col(c).alias(columnDict.get(c, c)) for c in df.columns])
         )
    
    return df

def clean_column_name(column_name):

    pattern = r"[-;{}()\n\t=&]"

    # Replace '-' with '_'
    column_name = re.sub(r"-", "_", column_name)

    # Replace empty spaces with ""
    column_name = re.sub(r" ", "_", column_name)
    column_name = re.sub(r"___", "_", column_name)
    column_name = re.sub(r"__", "_", column_name)

    # Replace invalid characters
    column_name = re.sub(pattern, "", column_name)

    return column_name

def remove_spaces_invalid_characters_in_column_names(df):

    # Iterate over columns and update names
    for column in df.columns:
        new_column_name = clean_column_name(column)
        df = df.withColumnRenamed(column, new_column_name)

    return df

# COMMAND ----------

def rename_columns(df, column_mappings):
    """
    Rename multiple columns

    Parameters:
    df (DataFrame): The DataFrame whose columns are to be renamed.
    column_mappings (dict): A dictionary mapping old column names to new column names.

    Returns:
    DataFrame: A DataFrame with renamed columns.
    """
    for old_name, new_name in column_mappings.items():
        df = df.withColumnRenamed(old_name, new_name)
    return df


def extract_field_names(schema):
    """
    Extract field names from a StructType schema.

    Args:
    - schema (StructType): The schema definition.

    Returns:
    - List[str]: A list of field names extracted from the schema.
    """
    field_names = []
    pattern = r"StructField\('([^']+)'"

    for field in schema.fields:
        field_str = str(field)
        match = re.search(pattern, field_str)
        if match:
            field_name = match.group(1)
            field_names.append(field_name)
    
    return field_names


def fill_nulls_with_zero_in_double_columns(df):
    """
    Fills null values with 0.0 in all columns of DoubleType
    """
    # Create a dictionary where the key is the column name and the value is 0.0
    fill_values = {col.name: 0.0 for col in df.schema.fields if isinstance(col.dataType, DoubleType)}
    
    # Fill null values in the DataFrame according to the dictionary
    df_filled = df.fillna(fill_values)
    
    return df_filled


def truncate_double_columns(df):
    """
    Truncates values in all DoubleType columns to 4 decimal points without rounding.
    Only applies to values with decimal points; integers pass through as-is.
    """
    for field in df.schema.fields:
        if isinstance(field.dataType, DoubleType):
            # Check if the value is effectively an integer or has decimal places
            df = df.withColumn(field.name, 
                               when(col(field.name).cast("long") == col(field.name), col(field.name))  # Pass through if integer
                               .otherwise((col(field.name) * 10000).cast("long") / 10000.0))  # Truncate if has decimal
    return df


# COMMAND ----------


def addColumnHash(df, hashColumnDefinition):
    
    for colName, hashCols in hashColumnDefinition.items():
        df = (df
              .withColumn(colName, sha2(concat_ws("|", *hashCols), 256))
             )
    return df

# COMMAND ----------

def get_parameters(source, sink):
    
    # Update the source path by adding sub folders for today's date
    updated_input_path = {'inputFilePath':source["source"]["inputFilePath"] + date.today().strftime("%Y/%m/%d")}
    sourcePath  = source["source"].update(updated_input_path)
    
    # TODO: no update needed at this time for sink
    
    return [source, sink]

# COMMAND ----------


# generate metadata per file and return json
def generate_metadata_json_per_file(df, processDatetime):
    # Group by file path and count rows
    if not df.isEmpty():
        file_grouped = df.groupBy("filepath").agg(count("*").alias("row_count"))

        # Collecting the metadata
        metadata_list = []
        for row in file_grouped.collect():
            metadata = {
                "filepath": row['filepath'],
                "size": row['row_count'],
                "processed_datetime": processDatetime
            }
            metadata_list.append(metadata)

        # Convert metadata list to JSON
        return json.dumps(metadata_list, indent=4)

# COMMAND ----------

def filter_rows_with_latest_date(df):
  # Find the latest date
  latest_date = df.agg({"processdatetime": "max"}).collect()[0][0]

  # Filter the DataFrame to only include rows with the latest date
  latest_df = df.filter(col("processdatetime") == latest_date)

  return latest_df

# COMMAND ----------

# DBTITLE 1,Shared fucntions for all notebooks
def rename_columns(df, rename_column_definition):

  # Construct a mapping definition
  rename_mapping = {rule["column"]: rule["name"] for rule in rename_column_definition}

  # Apply the renames for the columns
  df = reduce(lambda dataframe, names: dataframe.withColumnRenamed(names[0], names[1]), rename_mapping.items(), df)

  return df 

# COMMAND ----------

# DBTITLE 1,Daily trigger functions
def apply_audit_log(run_status_dict, source, sink, notebook_path, phase, load_type):
  
  #Generate base dict for audit logging
  base_audit_log = {
      "source":source, 
      "sink":sink, 
      "notebook_path":notebook_path, 
      "phase": phase, 
      "load_type": load_type, 
  }

  #Generate final dict for logging
  audit_log = base_audit_log | run_status_dict

  #Intiate the audit class
  audit = Audit()

  #Write msg to audit data load log table
  audit.write(audit_log)


def run_notebook(notebook_path, source, sink):
  
  try:
    # Run the notebook with set parameters
    result = dbutils.notebook.run(notebook_path, 0, {"source": source,"sink": sink})

    #Evaluate the string to a dictionary
    result=ast.literal_eval(result)

    #Update the run status
    run_status_dict={"run_status":"Successful"}

    #Merge the two dicts in to one
    run_status_dict = result | run_status_dict
  except Exception as e:
    #In-case error is raised
    run_status_dict = {
        "run_status":"Failed",
        "error_msg":str(e)
    }

  return run_status_dict



def raise_error(run_status_dict):
  if run_status_dict["run_status"] == "Failed":
    raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Curated Notebooks Functions

def find_previous_high_watermark(df, notebook_name):
    """
    Filters rows for a specific notebook name with a successful run status and finds the row with the highest process date time.

    Returns:
    DataFrame: A DataFrame containing the row with the latest successful process date time for the specified notebook.
    """

    #Audit table
    audit = spark.table("audit.data_load_log")

    # Filter the DataFrame for the specific notebook name and successful run status
    filtered_audit = audit.filter(col("notebook_path").contains(notebook_name) & (col("run_status") == "successful"))

    # Check if the filtered DataFrame is empty
    if filtered_audit.count() == 0:
        print(f"No successful runs found for notebooks containing '{notebook_name}'.")
        return None
    
    # Find the maximum process date time value for the filtered rows
    high_watermark = filtered_audit.agg(max(col("processed_datetime")).alias("max_process_date_time")).collect()[0]["max_process_date_time"]
    
    return high_watermark


def filter_non_null_columns(df: DataFrame, columns: list) -> DataFrame:
    """
    Filters the DataFrame to keep only rows where at least one of the specified columns is not null.

    Parameters:
    df (DataFrame): The input DataFrame to be filtered.
    columns (list): A list of column names to check for non-null values.

    Returns:
    DataFrame: The filtered DataFrame.
    """
    # Create a single filter expression that combines all the non-null checks
    non_null_filter = reduce(
        lambda a, b: a | b, 
        [F.col(column).isNotNull() for column in columns]
    )
    
    # Apply the filter to the dataframe
    return df.filter(non_null_filter)

def standardize_forecast_column(df, column_name):
    """
    Standardizes the forecast terms in the specified column of the DataFrame.
    
    Args:
    df (pyspark.sql.DataFrame): The input DataFrame.
    column_name (str): The name of the column to standardize.
    
    Returns:
    pyspark.sql.DataFrame: The DataFrame with standardized forecast terms.
    """
    # Month mapping
    month_mapping = {
        'Jan': 'January',
        'Feb': 'February',
        'Mar': 'March',
        'Apr': 'April',
        'May': 'May',
        'Jun': 'June',
        'Jul': 'July',
        'Aug': 'August',
        'Sep': 'September',
        'Oct': 'October',
        'Nov': 'November',
        'Dec': 'December'
    }
    
    # Replace "Actual" with "Actuals"
    df = df.withColumn(
        column_name,
        when(
            col(column_name).contains("Actual "),
            regexp_replace(col(column_name), "Actual ", "Actuals ")
        ).otherwise(col(column_name))
    )

    # Build the expressions for each month
    for short_month, full_month in month_mapping.items():
        df = df.withColumn(
            column_name,
            when(
                col(column_name).contains(f" {short_month} Fcst"),
                regexp_replace(col(column_name), f" {short_month} Fcst", f" {full_month} Forecast")
            ).otherwise(col(column_name))
        )

        df = df.withColumn(
            column_name,
            when(
                col(column_name).contains(f"{short_month} Fcst"),
                regexp_replace(col(column_name), f"{short_month} Fcst", f"{full_month} Forecast")
            ).otherwise(col(column_name))
        )
    
    return df



# COMMAND ----------

# DBTITLE 1,Refined Notebook Functions
def apply_column_definitions(df, column_definition):

  # Reorder the columns based on the column definitons 
  # Apply datatype as definied in the column definitions
  df = df.select(
      *[col(c["column"]).cast(c["datatype"]).alias(c["column"]) for c in column_definition]
  )

  return df 


def generate_stack_expression(account_types):

    # Calculate the number of unique account types (assuming each appears twice in your example)
    stack_n = len(account_types)
    # Generate the part of the expression that lists account types and their SQL-safe names
    stack_args = ",\n      ".join(f"'{name}', `{name}`" for name in account_types)
    # Combine everything into the full stack expression
    stack_expression = f"""stack({stack_n}, 
      {stack_args}
    ) 
    as (Account, Value)"""
    return stack_expression
  

def add_calculated_column_dynamic(df, base_column_name, numerator, denominator, account_type):
  
  # Dynamically construct the new column name
  new_column_name = f"{base_column_name}"

  # Apply the calculation
  return df.withColumn(new_column_name, col(numerator) / col(denominator))


def add_percentage_columns(df, percentage_columns, category):
    """
    Adds calculated percentage columns to the dataframe.

    Parameters:
    - df: The dataframe to modify.
    - percentage_columns: A list of tuples with (base_column_name, numerator, denominator).
    - category: The category to apply ("Internal" or "External").

    Returns:
    - The dataframe with added percentage columns.
    """
    for base_column_name, numerator, denominator in percentage_columns:
        df = add_calculated_column_dynamic(df, base_column_name, numerator, denominator, category)
    return df

