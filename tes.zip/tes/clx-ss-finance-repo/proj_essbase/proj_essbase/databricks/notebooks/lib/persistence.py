# Databricks notebook source
## Sample structure setup

class BasePrsistance(object):
  """
  Creates database if not created and then creating the
  delta tables within the same database.

  """
  def create_database_if_not_exist(database_name):
    
    query = f"CREATE DATABASE IF NOT EXISTS {database_name}"
    
    # create Database 
    spark.sql(query)
    
  def create_table_if_not_exist(table_name, destination_path):
    
    query = f"""CREATE TABLE IF NOT EXISTS {table_name} USING DELTA LOCATION '{destination_path}'"""
    
    # create delta table 
    spark.sql(query)


class WriteDela(BasePrsistance):

    """
    Write and merge to delta tables and setup connection string
    to SQL Server instance and write to SQL tables
    
    Attributes
    ------------
        
    Methods
    --------
    write_delta : 
    delta_merge_insert_records : 
    write_df_to_sql_server : 
    
    """

    def __init__(self, **kw):
      super(WriteDela, self).__init__(**kw)

# COMMAND ----------

def create_database_if_not_exist(database_name):
    
    query = f"CREATE DATABASE IF NOT EXISTS {database_name}"
    
    # create database 
    spark.sql(query)
    

def create_table_if_not_exist(table_name, destination_path):
    
    query = f"""CREATE TABLE IF NOT EXISTS {table_name} USING DELTA LOCATION '{destination_path}'"""
    
    # create delta table 
    spark.sql(query)

# COMMAND ----------

def write_delta(df, destinationPath, mode="append", partitionColumns=[]):
    
    # get the total record count
    recordCount = df.count()
    
    # write in delta format to storge location based on partition column
    (df.write
     .format("delta")
     .option("mergeSchema", "true")
     .mode(mode)
     .partitionBy(partitionColumns)
     .save(destinationPath)
    )
    return recordCount

# COMMAND ----------

from delta.tables import *

def delta_merge_insert_records(df_new, table_name, destination_path, unique_columns):
     
    """
    Merge to be performed on delta table.

    :param df_new: Spark DataFrame to be merged.
    :param table_new: Destination table to run merge on.
    :param unique_columns: Columns on which merge to be performed.
        
    """

    # Construct the merge condition based on unique columns
    # condition = " AND ".join([f"events.{col} = updates.{col}" for col in unique_columns])
    condition = " AND ".join([f"events.`{col}` = updates.`{col}`" if "&" in col else f"events.{col} = updates.{col}" for col in unique_columns])

    
    # Extract database and table name using index position
    db_name = table_name.split(".")[0]
    tb_name = table_name.split(".")[1]
    
    if spark._jsparkSession.catalog().tableExists(db_name, tb_name):
        
        deltaTable = DeltaTable.forPath(spark, destination_path)

        # deltaTable.toDF().printSchema()
        # df_new.printSchema()
        
        (deltaTable.alias("events")
         .merge(df_new.alias("updates"), condition)
         .whenNotMatchedInsertAll()
         .execute()
        )
        
        # get the number of rows inserted
        records_inserted = (deltaTable.history(1)
                            .withColumn("RowsInserted",col("operationMetrics.numTargetRowsInserted"))
                            .select("RowsInserted").collect()[0][0]
                           )
        
        return int(records_inserted)
    
    else:
        records_inserted = write_delta(df_new, destination_path, mode="overwrite", partitionColumns=[])
        
        # Create database if not exist
        create_database_if_not_exist(db_name)

        # Create table if not exist
        create_table_if_not_exist(destination_table_name, destination_path)
        
        return records_inserted

# COMMAND ----------

# DBTITLE 1,Azure SQL Server Connection
from pyspark.sql import DataFrame

def write_df_to_sql_server(df, table_name, mode: str = "append"):
    """
    Write a DataFrame to a SQL Server table.

    :param df: Spark DataFrame to write.
    :param table_name: Name of the table to write data into.
    :param mode: Write mode - 'append', 'overwrite', 'ignore', or 'error'.
    """
    server_name = "sql-ssefin-selfserv01"
    database_name = "SQLDB-SSEFIN-SELFSERV01"
    username = "SSEDATA_RW"
    password = dbutils.secrets.get(scope="KV-SSE-SCOPE", key="KV-SSEDATA")

    jdbc_url = f"jdbc:sqlserver://{server_name}.database.windows.net:1433;database={database_name};"
    
    connection_properties = {
        "user": username,
        "password": password,
        "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
    }

    try:
        df.write.jdbc(
            url=jdbc_url,
            table=table_name,
            mode=mode,
            properties=connection_properties
        )
    except Exception as e:
        print(f"Error writing DataFrame to SQL Server: {e}")

