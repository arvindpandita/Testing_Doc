# Databricks notebook source
import json

# COMMAND ----------

# DBTITLE 1,Raw Widgets
def get_raw_notebook_widgets():
    """
    Creates text input widgets in a Databricks notebook for user input.

    Widgets:
    - 'source': To input the source data location or configuration.
    - 'sink': To input the sink data location or configuration.

    No return value; widgets are created directly in the notebook's UI.
    
    """

    # List of widget names to be created
    raw_notebook_inputs = ["source", "sink"]

    # Create each widget as a text input field
    for widget in raw_notebook_inputs:
        dbutils.widgets.text(widget, "")


def get_parameters():
    """
    Retrieves parameter values from Databricks widgets and returns them as a dictionary.

    Returns:
        dict: A dictionary containing the parsed values of 'source' and 'sink'parameters.
              The keys of the dictionary are 'Source' and 'Sink'. If the respective widget
              is not set, the value will be None.

    Example:
        If Databricks widgets 'source' and 'sink' are set with JSON strings, this function
        will parse them and return a dictionary like:
        {"Source": <parsed source JSON>, "Sink": <parsed sink JSON>}
    """
    
    source_input = None
    sink_input = None

    if dbutils.widgets.get("source"):
        source_input = json.loads(dbutils.widgets.get("source"))
    
    if dbutils.widgets.get("sink"):
        sink_input = json.loads(dbutils.widgets.get("sink"))
    
    return {"Source":source_input, "Sink":sink_input}
    

# COMMAND ----------

# DBTITLE 1,Curated Widgets
def get_curated_notebook_widgets():
    """
    Creates text input widgets in a Databricks notebook for user input

    Widgets:
    - 'source': To input the source data location or configuration.
    - 'sink': To input the sink data location or configuration.

    No return value; widgets are created directly in the notebook's UI.
    """

    # List of widget names to be created
    raw_notebook_inputs = ["source", "sink"]

    # Create each widget as a text input field
    for widget in raw_notebook_inputs:
        dbutils.widgets.text(widget, "")


def get_curated_parameters():
    """
    Retrieves parameter values from Databricks widgets and returns them as a dictionary.

    Returns:
        dict: A dictionary containing the parsed values of 'source' and 'sink'parameters.
              The keys of the dictionary are 'Source' and 'Sink'. If the respective widget
              is not set, the value will be None.

    Example:
        If Databricks widgets 'source' and 'sink' are set with JSON strings, this function
        will parse them and return a dictionary like:
        {"Source": <parsed source JSON>, "Sink": <parsed sink JSON>}
    """
    
    source_input = None
    sink_input = None

    if dbutils.widgets.get("source"):
        source_input = json.loads(dbutils.widgets.get("source"))
    
    if dbutils.widgets.get("sink"):
        sink_input = json.loads(dbutils.widgets.get("sink"))
    
    return {"Source":source_input, "Sink":sink_input}
    

# COMMAND ----------

# DBTITLE 1,Consumption Widgets
def get_consumption_notebook_widgets():
    """
    Creates text input widgets in a Databricks notebook for user input

    Widgets:
    - 'source': To input the source data location or configuration.
    - 'sink': To input the sink data location or configuration.

    No return value; widgets are created directly in the notebook's UI.
    """

    # List of widget names to be created
    notebook_inputs = ["source", "sink"]

    # Create each widget as a text input field
    for widget in notebook_inputs:
        dbutils.widgets.text(widget, "")


def get_consumption_parameters():
    """
    Retrieves parameter values from Databricks widgets and returns them as a dictionary.

    Returns:
        dict: A dictionary containing the parsed values of 'source' and 'sink'parameters.
              The keys of the dictionary are 'Source' and 'Sink'. If the respective widget
              is not set, the value will be None.

    Example:
        If Databricks widgets 'source' and 'sink' are set with JSON strings, this function
        will parse them and return a dictionary like:
        {"Source": <parsed source JSON>, "Sink": <parsed sink JSON>}
    """
    
    source_input = None
    sink_input = None

    if dbutils.widgets.get("source"):
        source_input = json.loads(dbutils.widgets.get("source"))
    
    if dbutils.widgets.get("sink"):
        sink_input = json.loads(dbutils.widgets.get("sink"))
    
    return {"Source":source_input, "Sink":sink_input}
    
