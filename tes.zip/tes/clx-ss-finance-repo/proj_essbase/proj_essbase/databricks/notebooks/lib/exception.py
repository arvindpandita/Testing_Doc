# Databricks notebook source
class CustomException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.error_code = error_code
        super().__init__(message, error_code)
    
    def __str__(self):
        if self.error_code:
            return f'{self.message} (Error Code: {self.error_code})'
        return self.message

# COMMAND ----------


