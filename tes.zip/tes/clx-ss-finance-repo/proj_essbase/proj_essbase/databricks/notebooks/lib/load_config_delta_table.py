# Databricks notebook source
# DBTITLE 1,Load Common Libraries
# MAGIC %run ../Lib/Common

# COMMAND ----------

# DBTITLE 1,Create Databricks Database
create_database_if_not_exist("audit")

# COMMAND ----------

# DBTITLE 1,Pipelines
input_path = "/mnt/clx-datalake/deltalake/audit/iris/config/pipelines.xlsx"
destination_path = "/mnt/clx-datalake/deltalake/audit/iris/etl_metadata/pipeline/"

df_pipelines = spark.read.format("com.crealytics.spark.excel") \
.option("header", "true") \
.option("inferSchema", "true") \
.option("dataAddress", "'Sheet1'!A1") \
.load(input_path)

recordsCount_pipelines = write_delta(df_pipelines, destination_path, mode="overwrite", partitionColumns=[])

create_table_if_not_exist("audit.pipelines", destination_path)

# COMMAND ----------

# DBTITLE 1,Pipeline sources
input_path = "/mnt/clx-datalake/deltalake/audit/iris/config/pipeline_sources.xlsx"
destination_path = "/mnt/clx-datalake/deltalake/audit/iris/etl_metadata/pipeline_sources/"

df_pipeline_sources = spark.read.format("com.crealytics.spark.excel") \
.option("header", "true") \
.option("inferSchema", "true") \
.option("dataAddress", "'Sheet1'!A1") \
.load(input_path)

recordsCount_pipeline_sources = write_delta(df_pipeline_sources, destination_path, mode="overwrite", partitionColumns=[])

create_table_if_not_exist("audit.pipeline_sources", destination_path)

# COMMAND ----------

# DBTITLE 1,Pipeline target
input_path = "/mnt/clx-datalake/deltalake/audit/iris/config/pipeline_target.xlsx"
destination_path = "/mnt/clx-datalake/deltalake/audit/iris/etl_metadata/pipeline_target/"

df_pipeline_target = spark.read.format("com.crealytics.spark.excel") \
.option("header", "true") \
.option("inferSchema", "true") \
.option("dataAddress", "'Sheet1'!A1") \
.load(input_path)

recordsCount_pipeline_target = write_delta(df_pipeline_target, destination_path, mode="overwrite", partitionColumns=[])

create_table_if_not_exist("audit.pipeline_target", destination_path)

# COMMAND ----------

# DBTITLE 1,Pipeline tarnsformation
input_path = "/mnt/clx-datalake/deltalake/audit/iris/config/pipeline_tarnsformation.xlsx"
destination_path = "/mnt/clx-datalake/deltalake/audit/iris/etl_metadata/pipeline_tarnsformation/"

df_pipeline_tarnsformation = spark.read.format("com.crealytics.spark.excel") \
.option("header", "true") \
.option("inferSchema", "true") \
.option("dataAddress", "'Sheet1'!A1") \
.load(input_path)

recordsCount_pipeline_tarnsformation = write_delta(df_pipeline_tarnsformation, destination_path, mode="overwrite", partitionColumns=[])

create_table_if_not_exist("audit.pipeline_tarnsformation", destination_path)

# COMMAND ----------

# DBTITLE 1,Exit Notebook
valuesToReturn = {"recordCount": {"pipelines":recordsCount_pipelines, "pipeline_sources": recordsCount_pipeline_sources, "pipeline_target":recordsCount_pipeline_target, "pipeline_tarnsformation":recordsCount_pipeline_tarnsformation}}

dbutils.notebook.exit(valuesToReturn)

# COMMAND ----------


