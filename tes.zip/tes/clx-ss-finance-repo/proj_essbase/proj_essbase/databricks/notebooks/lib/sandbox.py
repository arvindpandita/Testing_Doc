# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC -- CREATE TABLE raw.forecast USING DELTA
# MAGIC --   LOCATION "/mnt/clx-datalake/finance/raw/essbase/forecast"
# MAGIC
# MAGIC select * from curated.driver_actuals_bucket where Category = "VMAP" and Account = "Volume" and SBU = 'Total Clorox'
# MAGIC and Year = 'FY24' and Quarter = 'Q2' and Scenario_Manager = "vs_YA" and Drill_Down_Type = 'Driver' and PL = "Gross Margin"
# MAGIC
# MAGIC

# COMMAND ----------


