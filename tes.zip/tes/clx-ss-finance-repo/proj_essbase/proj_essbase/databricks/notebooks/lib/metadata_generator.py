# Databricks notebook source
import json
import logging
from datetime import datetime
from pyspark.sql import Row, SparkSession
from pyspark.sql.functions import input_file_name, count

# COMMAND ----------

class MetadataGenerator:
    def __init__(self, spark: SparkSession, process_datetime: str = None):
        
        """
        Initializes the MetadataGenerator with a Spark session and optional processing datetime.
        If no processing datetime is provided, the current datetime is used.

        """
        self.spark = spark
        self.process_datetime = process_datetime or datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def generate_metadata_json_per_file(df, process_datetime):
        """
        Generates metadata per file for a given DataFrame and returns it as a JSON string.
        The metadata includes the filepath, size (row count), and processed datetime.

        """
        if not df.rdd.isEmpty():
            file_grouped = df.groupBy("filepath").agg(count("*").alias("row_count"))

            metadata_list = []
            for row in file_grouped.collect():
                metadata = {
                    "filepath": row['filepath'],
                    "size": row['row_count'],
                    "processed_datetime": process_datetime
                }
                metadata_list.append(metadata)

            return json.dumps(metadata_list, indent=4)
        else:
            return "[]"
