# Databricks notebook source
# MAGIC %scala
# MAGIC
# MAGIC // // container and storage information to connect to adls
# MAGIC // val containerName = "raw"
# MAGIC // val storageAccountName = "stpltdeviris01"
# MAGIC // val sas = "?sv=2021-06-08&ss=bfqt&srt=sco&sp=rwdlacupiyx&se=2022-12-10T10:24:55Z&st=2022-11-15T02:24:55Z&spr=https&sig=kQDqhQB%2BPO1ZpXkRp1vcmAAPagG4iukLBGsO6Mryy3o%3D"
# MAGIC // val config = "fs.azure.sas." + containerName+ "." + storageAccountName + ".blob.core.windows.net"
# MAGIC
# MAGIC // // mount adls starage container as /mnt/raw
# MAGIC // dbutils.fs.mount(
# MAGIC //   source = "wasbs://raw@stpltdeviris01.blob.core.windows.net/",
# MAGIC //   mountPoint = "/mnt/raw/",
# MAGIC //   extraConfigs = Map(config -> sas))

# COMMAND ----------

# DBTITLE 1,Check DBFS before mounting
# MAGIC %fs mounts

# COMMAND ----------

dbutils.fs.unmount("/mnt/raw")

# COMMAND ----------

# DBTITLE 1,Mount Ingress container from blob
# MAGIC %scala
# MAGIC
# MAGIC // container and storage information to connect to adls
# MAGIC val containerName = "ingress"
# MAGIC val storageAccountName = "stpltdeviris01"
# MAGIC val sas = "sp=racwdli&st=2022-11-29T01:09:26Z&se=2023-11-29T09:09:26Z&spr=https&sv=2021-06-08&sr=c&sig=%2BTEceWPkRvLtEkahoNvuPKfgpCNyefz1dq20ebgfkTM%3D"
# MAGIC val config = "fs.azure.sas." + containerName+ "." + storageAccountName + ".blob.core.windows.net"
# MAGIC
# MAGIC // mount adls starage container as /mnt/raw
# MAGIC dbutils.fs.mount(
# MAGIC   source = "wasbs://ingress@stpltdeviris01.blob.core.windows.net/",
# MAGIC   mountPoint = "/mnt/ingress/",
# MAGIC   extraConfigs = Map(config -> sas))

# COMMAND ----------

# DBTITLE 1,Mount Egress containers from blob
# MAGIC %scala
# MAGIC
# MAGIC // container and storage information to connect to adls
# MAGIC val containerName = "egress"
# MAGIC val storageAccountName = "stpltdeviris01"
# MAGIC val sas = "sp=racwdli&st=2022-11-29T15:34:21Z&se=2023-11-29T23:34:21Z&spr=https&sv=2021-06-08&sr=c&sig=anBMqWerLTN7ilvkmBQYG7lCu6ewseATQuLCXGw0T04%3D"
# MAGIC val config = "fs.azure.sas." + containerName+ "." + storageAccountName + ".blob.core.windows.net"
# MAGIC
# MAGIC // mount adls starage container as /mnt/raw
# MAGIC dbutils.fs.mount(
# MAGIC   source = "wasbs://egress@stpltdeviris01.blob.core.windows.net/",
# MAGIC   mountPoint = "/mnt/egress/",
# MAGIC   extraConfigs = Map(config -> sas))

# COMMAND ----------

# DBTITLE 1,Mount container from adls storage
# MAGIC %scala
# MAGIC
# MAGIC // container and storage information to connect to adls
# MAGIC val containerName = "clx-datalake"
# MAGIC val storageAccountName = "stssefinselfserv01"
# MAGIC val sas = "?sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupyx&se=2024-12-08T03:58:17Z&st=2023-12-07T19:58:17Z&spr=https&sig=bCBJ2fEKqOcXe%2FyUQcw0Zb3ORCI3O%2BgQFhQIbt1j420%3D"
# MAGIC val config = "fs.azure.sas." + containerName+ "." + storageAccountName + ".blob.core.windows.net"
# MAGIC
# MAGIC // mount adls starage container as /mnt/raw
# MAGIC dbutils.fs.mount(
# MAGIC   source = "wasbs://clx-datalake@stssefinselfserv01.blob.core.windows.net/",
# MAGIC   mountPoint = "/mnt/clx-datalake",
# MAGIC   extraConfigs = Map(config -> sas))

# COMMAND ----------

dbutils.fs.unmount("/mnt/clx-datalake")

# COMMAND ----------

# MAGIC %fs ls dbfs:/mnt/

# COMMAND ----------

# DBTITLE 1,Create delta databases


# COMMAND ----------

# DBTITLE 1,Create all available delta tables

