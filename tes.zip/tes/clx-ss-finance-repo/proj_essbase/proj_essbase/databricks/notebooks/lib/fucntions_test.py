import re
import json
from datetime import datetime
from pyspark.sql.functions import date_format, to_utc_timestamp, to_date, to_timestamp, when, sha2, concat_ws, input_file_name, count
from pyspark.sql.types import StringType


class HelperFunctions(object):

    def __init__(self):
        pass


    @staticmethod
    def get_columns_list(column_definitions: list[dict]) -> list:
        """
        Extracts and returns the list of column names from a list of column definitions.

        Parameters:
        column_definitions (list[dict]): A list of dictionaries, where each dictionary 
                                        represents a column definition and contains 
                                        a key 'columnName' with the column name as its value.

        Returns:
        list: A list of column names extracted from the column definitions.

        Raises:
        ValueError: If column_definitions is not a list or any of its elements do not contain 
                    the key 'columnName'.
        """
        if not isinstance(column_definitions, list):
            raise ValueError("column_definitions must be a list of dictionaries.")

        try:
            return [col_def["columnName"] for col_def in column_definitions]
        except KeyError:
            raise ValueError("Each dictionary in column_definitions must have a 'columnName' key.")
        
    def clean_column_name(self, column_name):

        pattern = r"[-;{}()\n\t=&]"

        # Replace '-' with '_'
        column_name = re.sub(r"-", "_", column_name)

        # Replace empty spaces with ""
        column_name = re.sub(r" ", "_", column_name)
        column_name = re.sub(r"___", "_", column_name)
        column_name = re.sub(r"__", "_", column_name)

        # Replace invalid characters
        column_name = re.sub(pattern, "", column_name)

        return column_name
    
    def remove_spaces_invalid_characters_in_column_names(self, df):

        # Iterate over columns and update names
        for column in df.columns:
            new_column_name = self.clean_column_name(column)
            df = df.withColumnRenamed(column, new_column_name)

        return df
