# Databricks notebook source
import json
import logging
from datetime import datetime
from pyspark.sql import Row, SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType
from pyspark.sql.functions import input_file_name, count, lit, monotonically_increasing_id, col, to_timestamp

# COMMAND ----------

# MAGIC %run ./persistence

# COMMAND ----------

class Logger:
    """
    Logger class 
    
    Attributes
    ------------
        
    Methods
    -------- 
    
    """

    def __init__(self, process_datetime: str = None, **kw):
        """
        parameters
        ----------
            
        """
        self.spark = SparkSession.builder.appName("logger").getOrCreate()
        self.process_datetime = process_datetime or datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    @classmethod
    def create_database_if_not_exist(cls, database_name):
    
        query = f"CREATE DATABASE IF NOT EXISTS {database_name}"
        
        # create database 
        spark.sql(query)
    
    @classmethod
    def create_table_if_not_exist(cls, table_name, destination_path):
        
        query = f"""CREATE TABLE IF NOT EXISTS {table_name} USING DELTA LOCATION '{destination_path}'"""
        
        # create table 
        spark.sql(query)

    def dict_to_dataframe(self, records, schema):
        """
        Converts a dictionary or a list of dictionaries into a Spark DataFrame based on a given schema.
        
        :param spark: SparkSession object
        :param records: A dictionary or list of dictionaries to convert
        :param schema: StructType schema that defines the DataFrame structure
        :return: DataFrame that conforms to the specified schema

        """
        
        # Ensure records is a dictionary and not a string for consistent processing
        if isinstance(records, str):
            records = json.loads(records)
    
        # Ensure records is a list for consistent processing
        if not isinstance(records, list):
            records = [records]
        
        # Adjust dictionaries to match the schema
        adjusted_records = []
        for record in records:
            adjusted_record = {}
            for field in schema.fields:
                adjusted_record[field.name] = record.get(field.name)
            adjusted_records.append(adjusted_record)
        
        # Convert adjusted records into Rows to maintain the order
        rows = [Row(**record) for record in adjusted_records]
        
        # Create DataFrame from Rows and Schema
        df = spark.createDataFrame(rows, schema=schema)
        
        return df

      
    def log(self, messages, log_table_path):
        """ Log messages to log table """

        messages.write.format("delta").mode("append").save(log_table_path)
        
        return messages.count()

    def get_logs(self):
        """ Return all logged messages. """
        return self.logs

# COMMAND ----------

class Audit(Logger):
    """ Subclass for logging table audit records. """

    def __init__(self, **kw):
        self.schema = StructType([
            StructField("audit_id", IntegerType(), True),
            StructField("source", StringType(), True),
            StructField("sink", StringType(), True),
            StructField("run_status", StringType(), True),
            StructField("error_msg", StringType(), True),
            StructField("notebook_path", StringType(), True),
            StructField("phase", StringType(), True),
            StructField("load_type", StringType(), True),
            StructField("message_count", IntegerType(), True),
            StructField("delta_rows_inserted", IntegerType(), True),
            StructField("sql_rows_inserted", IntegerType(), True),
            StructField("processed_datetime", TimestampType(), True)
        ])
        super(Audit, self).__init__(**kw)

    def write(self, data_load_log):
        """
        Validates the DataFrame against the internal schema and inserts it into
        the data_load_log Delta table path.
        """
        load_audit_table_name = "audit.data_load_log"
        load_audit_table_path = "/mnt/datalake/idr/deltalake/audit/data_load_log"
        
        # Update the data load log with processdate time
        # data_load_log = data_load_log | {"processed_datetime":self.process_datetime}

        #Create audit database if not exist
        Logger.create_database_if_not_exist("audit")

        #Create table if not exist
        Logger.create_table_if_not_exist(load_audit_table_name, load_audit_table_path)

        df = self.dict_to_dataframe(data_load_log, self.schema)

        df = df.withColumn('processed_datetime', lit(self.process_datetime).cast("timestamp"))

        # Increment the audit_id for new records
        deltaTable = self.spark.read.format("delta").load(load_audit_table_path)

        if not deltaTable.rdd.isEmpty():
            max_audit_id = deltaTable.selectExpr("max(audit_id) as max_audit_id").collect()[0]["max_audit_id"]
        else:
            max_audit_id = 0

        if max_audit_id is None:
            max_audit_id = 0
        else:
            max_audit_id = max_audit_id + 1 

        df = df.withColumn("audit_id", (monotonically_increasing_id() + lit(max_audit_id)).cast(IntegerType()))

        # Write the DataFrame to the Delta table
        record_count = write_delta(df, load_audit_table_path, mode="append", partitionColumns=[])

        print(f"Data inserted into {load_audit_table_path} with process datetime {self.process_datetime} and record count {record_count}")

# COMMAND ----------

class ProcessedFilesLogger(Logger):
    """ Subclass for logging processed files. """

    def __init__(self, **kw):
      """
      parameters
      ----------
          
      """
      super(ProcessedFilesLogger, self).__init__(**kw)
      
    def log_file_processed(self, metadata, log_table_path = "/mnt/clx-datalake/finance/audit/file_tracker_log"):
      """ Log details of a processed file. """
      
      if metadata is not None:
        data = json.loads(metadata)
        rows = [Row(**item) for item in data]

        log_messages = spark.createDataFrame(rows)

        self.log(log_messages, log_table_path)
      else:
        print("No files are read ")

    def get_processed_files_log(self):
        """ Return logs of processed files in JSON format. """
        return json.dumps(self.logs, indent=4)

# COMMAND ----------

from datetime import datetime

class IntegrationTestingLoggingHandler(logging.Handler):
    def __init__(self, spark_session, log_table_path):
        super().__init__()
        self.spark_session = spark_session
        self.log_table_path = log_table_path

    def emit(self, record):
        try:
            # Create a DataFrame with the log record
            log_row = Row(NotebookName=record.name,
                          Results=record.getMessage(),
                          processdatetime=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            log_df = self.spark_session.createDataFrame([log_row])

            # Write the DataFrame to the Delta table
            log_df.write.format("delta").option("mergeSchema", "true").mode("append").save(self.log_table_path)
        except Exception:
            self.handleError(record)

# COMMAND ----------

def setup_logging(spark_session, log_table_path):
    logger = logging.getLogger('IntegrationTestLogger')
    logger.setLevel(logging.INFO)

    # Add the custom IntegrationTestingLoggingHandler
    table_log_handler = IntegrationTestingLoggingHandler(spark_session, log_table_path)
    logger.addHandler(table_log_handler)

    return logger
