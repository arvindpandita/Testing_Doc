# Databricks notebook source
# MAGIC %md
# MAGIC Loading necessary libraries, running them on local cluster, checking mount point is available

# COMMAND ----------

import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

# COMMAND ----------

# MAGIC %run ./Lib/common

# COMMAND ----------

dbutils.fs.mounts()

# COMMAND ----------

# MAGIC %md
# MAGIC Drivers from Consolidation file

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import SparkSession

# Create a SparkSession
spark = SparkSession.builder.getOrCreate()

# Define the file path
file_path = "/mnt/clx-datalake/finance/landing/driver/FY24_Q1_Consolidation_Forecast.xlsx"



df = spark.read.format("com.crealytics.spark.excel") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .option("treatEmptyValuesAsNulls", "true") \
    .load(file_path)


# COMMAND ----------

df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Adding a column to stamp the date-time

# COMMAND ----------

df = df.withColumn('processdatetime', F.current_timestamp())
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Adding to SQL

# COMMAND ----------

server_name = "sql-ssefin-selfserv01"
db_name = "SQLDB-SSEFIN-SELFSERV01"
username = "SSEDATA_RW"
password = dbutils.secrets.get(scope="KV-SSE-SCOPE", key="KV-SSEDATA")
table_name = "dbo.raw_driver_forecast"

#overwrite
write_df_to_sql_server(df, server_name, db_name, table_name, username, password, mode = "overwrite")

#append
#write_df_to_sql_server(df, server_name, db_name, table_name, username, password, mode = "append")

# COMMAND ----------

# MAGIC %md
# MAGIC Total Clorox Consolidation

# COMMAND ----------

from pyspark.sql import functions as F

df_total = df.withColumn('Division', F.lit('Total Clorox')) \
             .withColumn('SBU', F.lit('Total Clorox')) \
              .withColumn('Segment', F.lit('Total Clorox')) \
             .groupBy('Scenario 1', 'Segment', 'Division', 'SBU', 'Year', 'Quarter', 'Scenario', 'P&L', 'Category', 'Account', 'Sub - Account', 'Driver', 'Drill Down Type', 'Number Type', 'Name Manager', 'Scenario Manager') \
             .agg(F.sum('Look up #').alias('Look up #'), F.sum('Measure (TBD)').alias('Measure (TBD)'))

df_total = df_total.withColumn('processdatetime', F.current_timestamp())
df_total.show()


# COMMAND ----------

# MAGIC %md
# MAGIC Append Total Cloroxto SQL

# COMMAND ----------

server_name = "sql-ssefin-selfserv01"
db_name = "SQLDB-SSEFIN-SELFSERV01"
username = "SSEDATA_RW"
password = dbutils.secrets.get(scope="KV-SSE-SCOPE", key="KV-SSEDATA")
table_name = "dbo.raw_driver_forecast"

write_df_to_sql_server(df_total, server_name, db_name, table_name, username, password, mode = "append")

# COMMAND ----------

# MAGIC %md
# MAGIC Loading Data - P&L from Consolidation

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import SparkSession

# Create a SparkSession
spark = SparkSession.builder.getOrCreate()

# Define the file path
file_path = "/mnt/clx-datalake/finance/landing/driver/FY24_Budget_Consolidation_P&L.xlsx"



df_pl = spark.read.format("com.crealytics.spark.excel") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .option("treatEmptyValuesAsNulls", "true") \
    .load(file_path)


# COMMAND ----------

df_pl.show()

# COMMAND ----------

from pyspark.sql import functions as F

df_pl = df_pl.withColumn('processdatetime', F.current_timestamp())
df_pl.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Add P&L to SQL

# COMMAND ----------

server_name = "sql-ssefin-selfserv01"
db_name = "SQLDB-SSEFIN-SELFSERV01"
username = "SSEDATA_RW"
password = dbutils.secrets.get(scope="KV-SSE-SCOPE", key="KV-SSEDATA")
table_name = "dbo.raw_driver_forecast_pl"

#overwrite
write_df_to_sql_server(df_pl, server_name, db_name, table_name, username, password, mode = "overwrite")

#append
#write_df_to_sql_server(df_pl, server_name, db_name, table_name, username, password, mode = "append")

# COMMAND ----------

# MAGIC %md
# MAGIC Total Clorox P&L Consolidation

# COMMAND ----------

from pyspark.sql import functions as F

df_total_pl = df_pl.withColumn('Division', F.lit('Total Clorox')) \
             .withColumn('SBU', F.lit('Total Clorox')) \
              .withColumn('Segment', F.lit('Total Clorox')) \
             .groupBy('Scenario 1', 'Segment', 'Division', 'SBU', 'Year', 'Quarter', 'Scenario', 'P&L', 'Category', 'Account', 'Sub - Account', 'Driver', 'Drill Down Type', 'Number Type', 'Name Manager', 'Scenario Manager') \
             .agg(F.sum('Look up #').alias('Look up #'), F.sum('Measure (TBD)').alias('Measure (TBD)'))

df_total_pl = df_total_pl.withColumn('processdatetime', F.current_timestamp())
df_total_pl.show()


# COMMAND ----------

# MAGIC %md
# MAGIC Append Total Clorox P&L to SQL

# COMMAND ----------

server_name = "sql-ssefin-selfserv01"
db_name = "SQLDB-SSEFIN-SELFSERV01"
username = "SSEDATA_RW"
password = dbutils.secrets.get(scope="KV-SSE-SCOPE", key="KV-SSEDATA")
table_name = "dbo.raw_driver_forecast_pl"

write_df_to_sql_server(df_total_pl, server_name, db_name, table_name, username, password, mode = "append")

# COMMAND ----------


