# Databricks notebook source
# MAGIC %md
# MAGIC #Overview
# MAGIC
# MAGIC | Detail Tag | Information |
# MAGIC | -------- | ------- |
# MAGIC | Description | To run this notebook, please copy and paste source and sink parameters to the widget's box in this notebook. </br> </br> Make sure to run the cell in the notebook with the `get_curated_notebook_widgets()` function to display the widgets.</br> </br> Additional documentation regarding this notebook is in the pipeline documentation page. |
# MAGIC | Source Parameter |<code>{"inputTable":"raw.driver_actuals_bucket"}<code/> |
# MAGIC | Sink Parameter |<code>{"sink":{"outputFilePath":"/mnt/clx-datalake/finance/curated/driver/actuals/bucket", <br>&nbsp&nbsp"tableName":"curated.driver_actuals_bucket",<br>&nbsp&nbsp"sqlTableName":"dbo.curated_driver_actuals_bucket"}}<code/>|
# MAGIC

# COMMAND ----------

# DBTITLE 1,Load Needed Modules
from pyspark.sql.types import StructType, StructField, StringType, FloatType
from pyspark.sql.functions import sum, avg, col, expr, lead, coalesce, lit, collect_set, size, trim, mean, when, regexp_extract
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,Load Common Libraries
# MAGIC %run ../lib/common

# COMMAND ----------

# DBTITLE 1,Create curated notebook widgets
get_curated_notebook_widgets()

# COMMAND ----------

# DBTITLE 1,Get Notebook parameters
parameters = get_curated_parameters()

# COMMAND ----------

# DBTITLE 1,Column Definitions
# Columns needed for insering unique records
unique_columns = [
  'Scenario_1', 
  'Segment',
  'Division',
  'SBU', 
  'Year', 
  'Quarter',
  'Scenario', 
  'PL', 
  'Category',
  'Account',
  'Sub_Account', 
  'Driver',
  'Drill_Down_Type',
  'Number_Type',
  'Name_Manager',
  'Scenario_Manager'
]


# Column used to agg refined table and take the average value of Measure_TBD
agg_columns_refined = ["Time", "Fiscal_Year", "Organization", "Scenario"]

# List of scenario conditions to filter for
actual_scenarios = [
    "Actuals", "Actual", "Actuals vs. YA", "Actual vs. YA"
]

# COMMAND ----------

# DBTITLE 1,Parameters
#get processed datetime
process_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# get Source parameters
input_table = parameters["Source"]["inputTable"]

# get Sink parameters
destination_path = parameters["Sink"]["sink"]["outputFilePath"]
destination_table_name = parameters["Sink"]["sink"]["tableName"]

db_name = destination_table_name.split(".")[0]

# COMMAND ----------

# DBTITLE 1,Read Delta
df = spark.read.table(input_table)

# Get total message count
df_message_count = df.count()

# COMMAND ----------

# DBTITLE 1,Get previous high watermark
previous_high_watermark = df.agg({"processdatetime": "max"}).collect()[0][0]

df = df.where(col("processdatetime").between(previous_high_watermark, process_datetime))

# COMMAND ----------

# DBTITLE 1,Load Refined Actuals
# Read refined actuals table
df_actuals = spark.table("refined.actuals")

#Get high watermark value for forecast table. Select only needed columns from refined table. 
actuals_high_watermark = df_actuals.agg({"refined_processdatetime": "max"}).collect()[0][0]

df_actuals  = (df_actuals
                .where(col("refined_processdatetime").between(actuals_high_watermark, process_datetime))
                .filter(
                      (col("Organization") == "Continuing Operations") &
                      (col("Internal_External") == "External")
                  )
                .filter(
                      (col("Total_Prior_Year_NCS").isNotNull()) |
                      (col("Total_Prior_Year_GP").isNotNull()) |
                      (col("Total_Current_Year_GP").isNotNull()) |
                      (col("Total_Current_Year_NCS").isNotNull())
                  )
                
                # Grouping the data by specified columns
                .groupby(agg_columns_refined)
                
                # Aggregating grouped data
                .agg(
                      # Caluclate avg values 
                      mean(col("Total_Prior_Year_NCS").cast("float")).alias('Total_Prior_Year_NCS'), 
                      mean(col("Total_Prior_Year_GP").cast("float")).alias('Total_Prior_Year_GP'), 
                      mean(col("Total_Current_Year_GP").cast("float")).alias('Total_Current_Year_GP'), 
                      mean(col("Total_Current_Year_NCS").cast("float")).alias('Total_Current_Year_NCS')
                  )
                
                # Replace values in Orgnization column to Total Clorox
                .withColumn("Organization", lit("Total Clorox"))
                
                # Select only the columns needed for further processing 
                .select([
                        "Time", 
                        "Fiscal_Year",
                        "Organization",
                        "Scenario",
                        "Total_Prior_Year_NCS", 
                        "Total_Prior_Year_GP",
                        "Total_Current_Year_GP", 
                        "Total_Current_Year_NCS"
                        ]
                  )
            )

# COMMAND ----------

# DBTITLE 1,Load Reference Comparison
# Function to create comparison rows and return updated DataFrame
def add_comparison_rows(df: DataFrame) -> DataFrame:

    # Collect the DataFrame to a list of Rows
    data = df.collect()

    # Find the maximum sequence value
    max_sequence = df.agg({"Sequence": "max"}).collect()[0][0]

    # Generate comparison rows
    new_rows = [
        Row(Sequence=max_sequence + idx + 1, 
            Fiscal_Year=row['Fiscal_Year'], 
            Scenario=row['Scenario'],
            Curr_Fcst_Scenario=row['Curr_Fcst_Scenario'],
            Curr_Fcst_Qtr=row['Curr_Fcst_Qtr'],
            Curr_Fcst_FY=row['Curr_Fcst_FY'],
            Prev_Fcst_Scenario=f"{row['Curr_Fcst_Scenario']} vs. {row['Prev_Fcst_Scenario']}",
            Prev_Fcst_FY=row['Prev_Fcst_FY'],
            YAGO_Scenario=row['YAGO_Scenario'],
            YAGO_FY=row['YAGO_FY'],
            YAGO2_Scenario=row['YAGO2_Scenario'],
            YAGO2_FY=row['YAGO2_FY'],
            filepath=row['filepath'],
            filename=row['filename'],
            processdatetime=row['processdatetime'])
        for idx, row in enumerate(data)
    ]

    # Create DataFrame for new rows
    df_new = spark.createDataFrame(new_rows, schema=df.schema)

    # Union the original DataFrame with the new DataFrame
    df_combined = df.union(df_new)

    return df_combined

# Perform inner join with comparison reference table
df_comparison = spark.table("reference.comparison").filter(col("Scenario") == "Actuals")

# Add the comparison rows to the dataframe
df_comparison = add_comparison_rows(df_comparison)

# COMMAND ----------

# DBTITLE 1,Load Refined Forecast
# Read refined forecast table
df_forecast = spark.table("refined.forecast")

#Get high watermark value for forecast table. Select only needed columns from refined table. 
forecast_high_watermark = df_forecast.agg({"refined_processdatetime": "max"}).collect()[0][0]

df_forecast  = (df_forecast
                .where(col("refined_processdatetime").between(forecast_high_watermark, process_datetime))
                .filter(
                      (col("Organization") == "Continuing Operations") &
                      (col("Internal_External") == "External")
                  )
                
                #Filter out all null values from the below columns
                .filter(
                      (col("Total_Prior_Year_NCS").isNotNull()) |
                      (col("Total_Prior_Year_GP").isNotNull()) |
                      (col("Total_Current_Year_GP").isNotNull()) |
                      (col("Total_Current_Year_NCS").isNotNull())
                  )
                .drop("Total_Prior_Year_NCS", "Total_Prior_Year_GP")
              )

join_condition_forecast = (
    (col("df_forecast.Fiscal_Year") == col("df_comparison.Fiscal_Year"))&
    (col("df_forecast.Time") == col("df_comparison.Curr_Fcst_Qtr")) &
    (col("df_forecast.Scenario") == col("df_comparison.Prev_Fcst_Scenario"))
)

# List of columns from forecast dataframe
joined_columns_forecast = [f"df_forecast.{column}" for column in df_forecast.columns]

df_forecast = (df_forecast.alias("df_forecast")
      .join(df_comparison.alias("df_comparison"), join_condition_forecast, "inner")
      .select(*joined_columns_forecast)
    )

# Agg dataframe and calculate the average for NCS and GP columns
df_forecast  = (df_forecast
                
                # Grouping the data by specified columns
                .groupby(agg_columns_refined)
                
                # Aggregating grouped data
                .agg(
                      # Caluclate avg values 
                      mean(col("Total_Current_Year_GP").cast("float")).alias('Total_Current_Year_GP'), 
                      mean(col("Total_Current_Year_NCS").cast("float")).alias('Total_Current_Year_NCS')
                  )
                
                # Replace values in Orgnization column to Total Clorox
                .withColumn("Organization", lit("Total Clorox"))

                .withColumnRenamed("Total_Current_Year_GP", "Total_Prior_Year_GP")
                .withColumnRenamed("Total_Current_Year_NCS", "Total_Prior_Year_NCS")
                
                # Select only the columns needed for further processing 
                .select([
                        "Time", 
                        "Fiscal_Year",
                        "Organization", 
                        "Scenario",
                        "Total_Prior_Year_GP", 
                        "Total_Prior_Year_NCS"
                        ]
                  )
            )

join_condition_forecast_actuals = (
    (col("df_forecast.Fiscal_Year") == col("df_actuals.Fiscal_Year"))&
    (col("df_forecast.Time") == col("df_actuals.Time")) &
    (col("df_forecast.Organization") == col("df_actuals.Organization"))
)

# List of columns from forecast dataframe
join_columns_forecast_actuals = [f"df_forecast.{column}" for column in df_forecast.columns] + ["df_actuals.Total_Current_Year_GP", "df_actuals.Total_Current_Year_NCS"]

# Join with Actuals table to get current year GP and NCS columns
df_forecast = (df_forecast.alias("df_forecast")
               .join(df_actuals.alias("df_actuals"), join_condition_forecast_actuals, "left")
               .select(*join_columns_forecast_actuals)
               )

# COMMAND ----------

# DBTITLE 1,Processing Scenario Column
def create_temp_scenario_column(df: DataFrame, scenario_column: str, new_column: str) -> DataFrame:
    """
    Adds a new column to the DataFrame by extracting "Month Forecast" or "Budget" from the specified scenario column.
    
    Args:
    df (pyspark.sql.DataFrame): The input DataFrame.
    scenario_column (str): The name of the column containing the scenario values.
    new_column (str): The name of the new column to be created.
    
    Returns:
    pyspark.sql.DataFrame: The DataFrame with the new column added.
    """
    # Define regex patterns
    forecast_pattern = r"(?:Actuals vs\. )?(\w+ Forecast)"
    budget_pattern = r"(?:Actuals vs\. )?(Budget)"

    # Add the new column based on the regex patterns
    df = df.withColumn(new_column,
        when(
            col(scenario_column).rlike(budget_pattern),
            regexp_extract(col(scenario_column), budget_pattern, 1)
        ).otherwise(
            regexp_extract(col(scenario_column), forecast_pattern, 1)
        )
    )
    
    return df

# COMMAND ----------

# DBTITLE 1,Processing NCS and Generate NCS Impact Values
def generate_ncs_data(
    df_total_clorox: DataFrame, 
    df_refined: DataFrame, 
    agg_columns: list, 
    join_conditions: dict) -> DataFrame:
    """
    Processes and joins two DataFrames with specific aggregations, join conditions, and column selections.

    Parameters:
    df_total_clorox (DataFrame): DataFrame containing updated data to be aggregated.
    df_refined (DataFrame): Reference DataFrame to be joined with.
    agg_columns (list): List of column names for grouping and aggregation.
    join_conditions (dict): Dictionary specifying the columns to match for the join.

    Returns:
    DataFrame: The processed DataFrame.
    """
    # Aggregating the updated DataFrame
    df_ncs = (df_total_clorox
              .filter(col("PL").contains("NCS"))
              .groupby(agg_columns)
              .agg(sum(col("Measure_TBD").cast("float")).alias('Measure_TBD'))
             )

    # Creating join condition from the dictionary
    join_condition = lit(True)
    for key, value in join_conditions.items():
        join_condition &= (col(f"df_ncs.{key}") == col(f"df_refined.{value}"))


    select_columns = [f"df_ncs.{column}" for column in df_ncs.columns] + ["df_refined.Total_Prior_Year_NCS"]

    # Performing the join and selecting columns
    df_ncs = (df_ncs.alias("df_ncs")
              .join(df_refined.alias("df_refined"), join_condition, "left")
              .select(*select_columns)
             )

    # Calculate additional fields
    df_ncs = (df_ncs
              .withColumn('Measure_TBD', col('Measure_TBD') * 1000000) 
              .withColumn('NCS_Impact', col('Measure_TBD') + col('Total_Prior_Year_NCS'))
             )

    return df_ncs

# COMMAND ----------

# DBTITLE 1,Generate Gross Margin Dataframe
def generate_gm_data(
    df_total_clorox: DataFrame, 
    df_refined: DataFrame, 
    filter_condition: str, 
    join_keys: dict,
    refined_columns: list) -> DataFrame:
    """
    Processes data by filtering, removing duplicates, joining with another DataFrame,
    and selecting specified columns.

    Parameters:
    df_total_clorox (DataFrame): DataFrame containing updated data to be processed.
    df_refined (DataFrame): Reference DataFrame to be joined with.
    filter_condition (str): Condition string used for filtering the DataFrame.
    join_keys (dict): Dictionary specifying the columns to match for the join.
    refined_columns (list): List of column names to include from the actuals DataFrame after the join.

    Returns:
    DataFrame: The processed DataFrame.
    """
    # Filter and drop duplicates in the updated DataFrame
    df_gm = (df_total_clorox
             .filter(col("PL").contains(filter_condition))
             .dropDuplicates()
            )
    
    # Creating join condition from the dictionary
    join_condition = lit(True)
    for df_gm_key, df_actuals_key in join_keys.items():
        join_condition &= (col(f"df_gm.{df_gm_key}") == col(f"df_refined.{df_actuals_key}"))

    # Combining the column lists for selection
    select_columns = [f"df_gm.{column}" for column in df_gm.columns] + [f"df_refined.{column}" for column in refined_columns]

    # Performing the join and selecting columns
    df_gm = (df_gm.alias("df_gm")
             .join(df_refined.alias("df_refined"), join_condition, "left")
             .select(*select_columns)
            )

    return df_gm

# COMMAND ----------

# DBTITLE 1,Join NCS and Gross Margin Dataframe
def process_gross_margin(df_gm: DataFrame, df_ncs: DataFrame, join_keys: dict,) -> DataFrame:
    """
    Joins Gross Margin data with NCS impacts, handles null values, performs financial calculations,
    and cleans up the dataset by dropping unnecessary columns and renaming as required.

    Parameters:
    df_gm (DataFrame): DataFrame containing Gross Margin data.
    df_ncs (DataFrame): DataFrame containing NCS impact data.

    Returns:
    DataFrame: The processed DataFrame with financial metrics and necessary transformations.
    """

    # Creating join condition from the dictionary
    join_condition = lit(True)
    for df_gm_key, df_actuals_key in join_keys.items():
        join_condition &= (col(f"df_gm.{df_gm_key}") == col(f"df_ncs.{df_actuals_key}"))

    # List of columns to select after joining
    joined_columns = [f"df_gm.{column}" for column in df_gm.columns] + ["df_ncs.NCS_Impact"]

    # Join the DataFrames
    df_gm = (df_gm.alias("df_gm")
             .join(df_ncs.alias("df_ncs"), join_condition, "left")
             .select(*joined_columns))

    # Some account might not have NCS, in thise case replace the null values with Total_Prior_Year_NCS
    # If the ncs impact is null, then replace the values from Total_Prior_Year_NCS
    df_gm = df_gm.withColumn("NCS_Impact", coalesce(col("NCS_Impact"), col("Total_Prior_Year_NCS")))

    # Perform calculations
    df_gm = (df_gm
             
             # Perform the calculations 
             .withColumn('Measure_TBD', col('Measure_TBD') * 1000000)
             .withColumn('GP_Impact', col('Measure_TBD') + col('Total_Prior_Year_GP'))
             .withColumn('Gross_Profit', col('GP_Impact') / col('NCS_Impact'))
             .withColumn('Prev_Gross_Profit', col('Total_Prior_Year_GP') / col('Total_Prior_Year_NCS'))
             .withColumn('BPS', (col('Gross_Profit') - col('Prev_Gross_Profit')) * 10000)
             
             # Calculate Curr year gross margin 
             .withColumn('Curr_Gross_Profit', col('Total_Current_Year_GP') / col('Total_Current_Year_NCS'))
             .withColumn('Total_BPS', (col('Curr_Gross_Profit') - col('Prev_Gross_Profit')) * 10000)
             
             # Update PL colum to Gross Margin
             .withColumn("PL", lit("Gross Margin"))
             
             # Drop unwanted columns
             .drop(*[
                    "Total_Prior_Year_NCS",
                    "Total_Prior_Year_GP",
                    "Total_Current_Year_GP", 
                    "Total_Current_Year_NCS",
                    "NCS_Impact",
                    "GP_Impact",
                    "Gross_Profit",
                    "Prev_Gross_Profit",
                    "Curr_Gross_Profit",
                    "Measure_TBD"
                    ]
                )
             
             # Rename BPS to measure tbd
             .withColumnRenamed("BPS", "Measure_TBD")
             
             # Drop any duplicated records
             .dropDuplicates())

    return df_gm

# COMMAND ----------

# DBTITLE 1,Calculate BPS Difference
def calculate_bps_difference(df: DataFrame) -> DataFrame:
    """
    Calculates the difference between BPS and total BPS for given DataFrame columns,
    aggregates the data, and adjusts the schema as specified.

    Parameters:
    df (DataFrame): The DataFrame to process, which contains BPS-related data.

    Returns:
    DataFrame: The DataFrame with calculated differences and necessary transformations.
    """
    # Group by specified columns and aggregate
    df_bps_difference = (df
                         .groupBy(
                             "Scenario_1", "Segment", "Division", "SBU", "Year",
                             "Quarter", "Scenario", "PL", "Drill_Down_Type",
                             "Number_Type", "Scenario_Manager"
                         )
                         .agg(
                             sum('Measure_TBD').alias('Measure_TBD'),
                             collect_set('Total_BPS').alias('Total_BPS')
                         )
                         .filter(size(col("Total_BPS")) == 1)  # Ensure only one unique value per group
                         .withColumn("Total_BPS", col("Total_BPS")[0])  # Flatten the set to a single value
                         .withColumn("Measure_TBD", col("Total_BPS") - col("Measure_TBD"))  # Calculate the difference
                         
                         # Add all remaning column to match schema with main dataframe with defult value "All Other" 
                         .withColumn("Category", lit("All Other"))
                         .withColumn("Account", lit("All Other"))
                         .withColumn("Sub_Account", lit("All Other"))
                         .withColumn("Driver", lit("All Other"))
                         .withColumn("Name_Manager", lit("Gross Margin"))

                         .drop("Total_BPS")  # Remove the Total_BPS column after use
                         .dropDuplicates()  # Drop any duplicate records
                        )

    return df_bps_difference

# COMMAND ----------

# DBTITLE 1,Start Data Processing - Generate total colorox dataframe
# Values to exclude from agg columns in the dataframe
values_to_exclude = [
  'Look_up_#', 
  'Measure_TBD', 
  'filepath', 
  'filename', 
  'processdatetime'
]

# Get list of columns except the ones to exclude
agg_columns = [col for col in df.columns if col not in values_to_exclude]

# Drop look up number columns from main dataframe
df = (df
      
      .withColumn("Quarter", trim(col("Quarter")))
      
      # Filter duplicated records that maybe coming in diffrent files
      .filter(
        ((col("Quarter") == "FY") & col("filename").rlike("(?i)Q4_FY"))
        | ((col("Quarter") == "Q1") & col("filename").rlike("(?i)Q1_FY")) 
        | ((col("Quarter") == "Q2") & col("filename").rlike("(?i)Q2_FY")) 
        | ((col("Quarter") == "Q3") & col("filename").rlike("(?i)Q3_FY")) 
        | ((col("Quarter") == "Q4") & col("filename").rlike("(?i)Q4_FY")) 
      )
      .drop(*[
            "Look_up_#",
            "filepath",
            "filename",
            "processdatetime"]
      )
)

# Consolidating the total company fiancial driver summary
# Agg and sum lookup number and measure columns 
df_total_clorox = (df
              
      # Update the values for Sub_Account and Driver where Account equals Mix / Assortment with the value "Mix / Assortment"
      .withColumn("Sub_Account", when(col("Account") == "Mix / Assortment", "Mix / Assortment").otherwise(col("Sub_Account")))
      .withColumn("Driver", when(col("Account") == "Mix / Assortment", "Mix / Assortment").otherwise(col("Driver")))

      # Adding constant columns with the same value 'Total Clorox'
      .withColumn('Division', lit('Total Clorox'))  
      .withColumn('SBU', lit('Total Clorox'))       
      .withColumn('Segment', lit('Total Clorox'))

      # Exclude values in PL with "Gross Margin"
      .filter(col("PL") != "Gross Margin")

      # Grouping the data by specified columns
      .groupby(agg_columns)  
    
      # Aggregating grouped data
      .agg(
        # Summing up the 'Measure_TBD' column 
        sum(col("Measure_TBD").cast("float")).alias('Measure_TBD')
    )
)

# COMMAND ----------

# DBTITLE 1,Process Actuals rows from total clorox dataframe
# Filter total clorox dataframe for actuals rows
df_actuals_total_clorox = df_total_clorox.filter(
    col("Scenario").isin(actual_scenarios)
)

#Agg ncs dataframe and calculate NCS Impact value 
agg_columns_ncs = ["SBU", "Year", "Quarter", "Scenario", "Account", "Drill_Down_Type"]
join_conditions = {
    "Quarter": "Time",
    "Year": "Fiscal_Year",
    "SBU": "Organization"
}

# Assuming df_updated and df_actuals are already loaded
df_actuals_ncs_impact = generate_ncs_data(df_actuals_total_clorox, df_actuals, agg_columns_ncs, join_conditions)

# Generate Gross Margin Dataframe
filter_condition = "Gross Profit"
join_keys = {
    "Quarter": "Time",
    "Year": "Fiscal_Year"
}
actuals_columns = ["Total_Prior_Year_NCS", "Total_Prior_Year_GP", "Total_Current_Year_GP", "Total_Current_Year_NCS"]

df_actuals_gm = generate_gm_data(df_actuals_total_clorox, df_actuals, filter_condition, join_keys, actuals_columns)

# Process Gross Margin dataframe and calculate bps
actuals_gm_ncs_impact_join_keys = {
    "Quarter": "Quarter",
    "Year": "Year",
    "Scenario":"Scenario",
    "Account":"Account",
    "Drill_Down_Type":"Drill_Down_Type"
}

df_actuals_gm = process_gross_margin(df_actuals_gm, df_actuals_ncs_impact, actuals_gm_ncs_impact_join_keys)

# Calculate bps diffrence from Gross Margin dataframe
df_actuals_bps_diff = calculate_bps_difference(df_actuals_gm)

# Remove Total_BPS column from Gross Margin dataframe
df_actuals_gm = df_actuals_gm.drop("Total_BPS")

# COMMAND ----------

# DBTITLE 1,Process Forecast rows from total clorox dataframe
# Filter total clorox dataframe for forecast rows
df_forecast_total_clorox = df_total_clorox.filter(
    ~col("Scenario").isin(actual_scenarios)
)

df_forecast_total_clorox = standardize_forecast_column(df_forecast_total_clorox, column_name = "Scenario")

# Number of partitions can be adjusted based on the size of your cluster
num_partitions = 200

df_forecast_total_clorox = df_forecast_total_clorox.repartition(num_partitions)
df_forecast = df_forecast.repartition(num_partitions)

# Cache the DataFrames
df_forecast_total_clorox.cache()
df_forecast.cache()

# Create temp_scenario column:extract the "Month Forecast" part
df_forecast_total_clorox = create_temp_scenario_column(df_forecast_total_clorox , "Scenario", "Temp_Scenario")
df_forecast = create_temp_scenario_column(df_forecast , "Scenario", "Temp_Scenario")

#Agg ncs dataframe and calculate NCS Impact value 
agg_columns_ncs = ["SBU", "Year", "Quarter", "Scenario", "Account", "Drill_Down_Type", "Temp_Scenario"]
join_conditions = {
    "Quarter": "Time",
    "Year": "Fiscal_Year",
    "SBU": "Organization",
    "Temp_Scenario":"Temp_Scenario"
}

# Assuming df_updated and df_actuals are already loaded
df_forecast_ncs_impact = generate_ncs_data(df_forecast_total_clorox, df_forecast, agg_columns_ncs, join_conditions)

df_forecast_ncs_impact.cache()

# Generate Gross Margin Dataframe
filter_condition = "Gross Profit"
forecast_join_keys = {
    "Quarter": "Time",
    "Year": "Fiscal_Year",
    "Temp_Scenario":"Temp_Scenario"
}

refined_columns = ["Total_Prior_Year_NCS", "Total_Prior_Year_GP", "Total_Current_Year_GP", "Total_Current_Year_NCS"]

df_forecast_gm = generate_gm_data(df_forecast_total_clorox, df_forecast, filter_condition, forecast_join_keys, refined_columns)

# Process Gross Margin dataframe and calculate bps
forecast_gm_ncs_impact_join_keys = {
    "Quarter": "Quarter",
    "Year": "Year",
    "Temp_Scenario":"Temp_Scenario",
    "Account":"Account",
    "Drill_Down_Type":"Drill_Down_Type"
}
df_forecast_gm = process_gross_margin(df_forecast_gm, df_forecast_ncs_impact, forecast_gm_ncs_impact_join_keys)

# Calculate bps diffrence from Gross Margin dataframe
df_forecast_bps_diff = calculate_bps_difference(df_forecast_gm)

# Remove Total_BPS column from Gross Margin dataframe
df_forecast_gm = df_forecast_gm.drop("Total_BPS", "Temp_Scenario")
df_forecast_total_clorox = df_forecast_total_clorox.drop("Temp_Scenario")


# COMMAND ----------

# DBTITLE 1,Join all dataframes into one final dataframe
# Perform the union operations
final_df = (
    df
    .unionByName(df_actuals_gm, allowMissingColumns=True)
    .unionByName(df_forecast_gm, allowMissingColumns=True)
    .unionByName(df_actuals_bps_diff, allowMissingColumns=True)
    .unionByName(df_forecast_bps_diff, allowMissingColumns=True)
    .unionByName(df_actuals_total_clorox, allowMissingColumns=True)
    .unionByName(df_forecast_total_clorox, allowMissingColumns=True)
    .dropDuplicates()
)

# Add curated_processdatetime column
final_df = final_df.withColumn("curated_processdatetime", lit(process_datetime).cast(TimestampType()))

# COMMAND ----------

# DBTITLE 1,Write to Delta
records_inserted = delta_merge_insert_records(final_df, destination_table_name, destination_path, unique_columns)

# Create database if not exist
create_database_if_not_exist(db_name)

# Create table if not exist
create_table_if_not_exist(destination_table_name, destination_path)

# COMMAND ----------

# DBTITLE 1,Write to Sql DB
# Read entire dataframe
total_df = spark.table(destination_table_name)

# sql db table names
sql_table_name = parameters["Sink"]["sink"]["sqlTableName"]

# Write to sql server db
write_df_to_sql_server(total_df, sql_table_name, mode = "overwrite")

# COMMAND ----------

# DBTITLE 1,Exit Notebook
valuesToReturn = {
  "delta_rows_inserted": records_inserted, 
  "message_count":df_message_count,
  "sql_rows_inserted":total_df.count()
}

dbutils.notebook.exit(valuesToReturn)
