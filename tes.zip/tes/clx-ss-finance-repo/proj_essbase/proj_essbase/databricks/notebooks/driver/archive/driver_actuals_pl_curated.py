# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType, FloatType
from pyspark.sql.functions import sum, col

# COMMAND ----------

# DBTITLE 1,Load Common Libraries
# MAGIC %run ../lib/Common

# COMMAND ----------

# DBTITLE 1,Create curated notebook widgets
get_curated_notebook_widgets()

# COMMAND ----------

# DBTITLE 1,Get Notebook parameters
parameters = get_curated_parameters()

# COMMAND ----------

# DBTITLE 1,Define input and output parameters
source = {
      "inputTable": "raw.driver_actuals_profit_loss"
      }

sink = {
      "sink":{"outputFilePath":"/mnt/clx-datalake/finance/curated/driver/actuals/profit_loss", 
              "tableName":"curated.driver_actuals_profit_loss",
              "sqlTableName":"dbo.curated_driver_actuals_profit_loss"
            }
      }

# COMMAND ----------

# DBTITLE 1,Column Definitions
unique_columns = ['Scenario_1', 'SBU', 'Year', 'Scenario', 'PL', 'Account', 'Sub_Account', 'Driver']

# COMMAND ----------

# DBTITLE 1,Parameters
#get processed datetime
process_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# get Source parameters
input_table = parameters["Source"]["inputTable"]

# get Sink parameters
destination_path = parameters["Sink"]["sink"]["outputFilePath"]
destination_table_name = parameters["Sink"]["sink"]["tableName"]

db_name = destination_table_name.split(".")[0]

# COMMAND ----------

# DBTITLE 1,Read Delta
df = spark.read.table(input_table)

# Get total message count
df_message_count = df.count()

# COMMAND ----------

# DBTITLE 1,Get previous high wantermark
previous_high_watermark = df.agg({"processdatetime": "max"}).collect()[0][0]

df = df.where(col("processdatetime").between(previous_high_watermark, process_datetime))

# COMMAND ----------

# DBTITLE 1,Processing
# Update columns with specific values
df = (df
      .withColumn('Division', lit('Total Clorox'))
      .withColumn('SBU', lit('Total Clorox'))
      .withColumn('Segment', lit('Total Clorox')) 
    )

# Columns to exclude
exclude_columns = ['Look_up_#', 'Measure_TBD', "filepath", "filename", "processdatetime", 'Prev_Period_GP', 'Curr_Period_NCS', 'Curr_Period_GP', 'Prev_Period_NCS']

# Get list of columns except the ones to exclude
agg_columns = [col for col in df.columns if col not in exclude_columns]

# Agg and sum lookup number and measure columns 
df = (df
      .groupby(agg_columns)
      .agg(
            sum(col("Measure_TBD").cast("float")).alias('Measure_TBD')
            ,sum(col("Look_up_#").cast("float")).alias('Look_up_#')
      )
    )
    
# Add process datetime and update dattime columns 
df = df.withColumn("processdatetime", to_timestamp(lit(process_datetime))) 

# COMMAND ----------

# DBTITLE 1,Write to Delta
records_inserted = delta_merge_insert_records(df, destination_table_name, destination_path, unique_columns)

# Create database if not exist
create_database_if_not_exist(db_name)

# Create table if not exist
create_table_if_not_exist(destination_table_name, destination_path)

# COMMAND ----------

# DBTITLE 1,Write to Sql DB
# Read entire dataframe
total_df_actuals = spark.table(destination_table_name)

# sql db table names
sql_table_name = parameters["Sink"]["sink"]["sqlTableName"]

# Write to sql server db
write_df_to_sql_server(total_df_actuals, sql_table_name, mode = "overwrite")

# COMMAND ----------

# DBTITLE 1,Exit Notebook
valuesToReturn = {"recordInserted":records_inserted, "messageCount": df_message_count}

dbutils.notebook.exit(valuesToReturn)
