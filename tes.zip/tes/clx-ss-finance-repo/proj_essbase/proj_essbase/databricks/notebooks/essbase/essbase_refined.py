# Databricks notebook source
# MAGIC %md
# MAGIC #Overview
# MAGIC
# MAGIC | Detail Tag | Information |
# MAGIC | -------- | ------- |
# MAGIC | Description | To run this notebook, please copy and paste source and sink parameters to the widget's box in this notebook. </br> </br> Make sure to run the cell in the notebook with the`get_consumption_notebook_widgets` function to display the widgets.</br> </br> Additional documentation regarding this notebook is in the pipeline documentation page. |
# MAGIC | Source Parameter |  `source = {"inputTable": "curated.forecast"}` |
# MAGIC | Sink Parameter |    <code>sink = { "sink":{"outputFilePath":"/mnt/clx-datalake/finance/refined/essbase/forecast", <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp"tableName":"refined.forecast",<br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp"sqlTableName":"dbo.refined_forecast"}<br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp}</code>|

# COMMAND ----------

from datetime import datetime
from pyspark.sql import Window
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, TimestampType
from pyspark.sql.functions import col, when, expr, lit, coalesce, count, row_number, sum, sum as _sum

# COMMAND ----------

# DBTITLE 1,Load Common Libraries
# MAGIC %run ../lib/common

# COMMAND ----------

# DBTITLE 1,Create curated notebook widgets
get_consumption_notebook_widgets()

# COMMAND ----------

# DBTITLE 1,Get curated parameters
parameters = get_consumption_parameters()

# COMMAND ----------

# DBTITLE 1,Column Definition
column_definition = [
    {"column": "Time", "datatype": StringType()},
    {"column": "Organization", "datatype": StringType()},
    {"column": "Fiscal_Year", "datatype": StringType()},
    {"column": "Account", "datatype": StringType()},
    {"column": "Scenario", "datatype": StringType()},
    {"column": "Flag", "datatype": StringType()},
    {"column": "Internal_External", "datatype": StringType()},
    {"column": "Value", "datatype": DoubleType()},
    {"column": "Total_Value_YA", "datatype": DoubleType()},
    {"column": "Total_Current_Year_NCS", "datatype": DoubleType()},
    {"column": "Total_Prior_Year_NCS", "datatype": DoubleType()},
    {"column": "Total_Current_Year_GP", "datatype": DoubleType()},
    {"column": "Total_Prior_Year_GP", "datatype": DoubleType()},
    {"column": "refined_processdatetime", "datatype": TimestampType()}
]

rename_column_definition = [
    {"column": "Scenario_FYXX", "name": "Fiscal_Year"},
    {"column": "Scenario_lv_2", "name": "Scenario"}
]

# Percentage calculation columns 
# Example: Gross Margin = Gross Profit / Net Customer Sales
percentage_columns = [
    ("Gross Margin", "Gross Profit", "Net Customer Sales"),
    ("COGS / SC ($)", "Cost of Sales", "Volume"),
    ("Gross Profit / SC ($)", "Gross Profit", "Volume"),
    ("NCS / SC ($)", "Net Customer Sales", "Volume"),
    ("Red Rev % of NCS", "Reduced Revenue", "Net Customer Sales"),
    ("EBIT Margin", "EBIT", "Net Customer Sales"),
    ("Operating Profit Margin", "Operating Profit", "Net Customer Sales"),
    ("Pretax Profit Margin", "Pretax Profit", "Net Customer Sales"),
    ("SBU EBIT Margin", "SBU EBIT", "Net Customer Sales"),
    ("SBU Profit Margin", "SBU Profit", "Net Customer Sales"),
    ("Total Adv. & SP % of NCS", "`Total Adv. & Sales Promo.`", "Net Customer Sales"),
    ("Total Selling & Admin % of NCS", "Total Selling & Admin", "Net Customer Sales")
]

# COMMAND ----------

# DBTITLE 1,Parameters
#get processed datetime
process_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# get Source parameters
input_table = parameters["Source"]["inputTable"]

# get Sink parameters
destination_path = parameters["Sink"]["sink"]["outputFilePath"]
destination_table_name = parameters["Sink"]["sink"]["tableName"]

db_name = destination_table_name.split(".")[0]

# COMMAND ----------

# DBTITLE 1,Read Delta
df = spark.read.table(input_table)

# Get total message count
df_message_count = df.count()

# COMMAND ----------

# DBTITLE 1,Get  previous high watermark
previous_high_watermark = df.agg({"processdatetime": "max"}).collect()[0][0]

df = df.where(col("processdatetime").between(previous_high_watermark, process_datetime))

# COMMAND ----------

# DBTITLE 1,Processing
# Specify the columns to group by
group_columns = [
    col("Time"), 
    col("Scenario_FYXX"), 
    col("Organization"), 
    col("Account"),
    col("Scenario_lv_2"),
    col("Flag")  
]

# List of columns to sum when grouping
columns_to_sum = [
    "Value", 
    "Value_YA", 
    "Current_Year_NCS", 
    "Prior_Year_NCS", 
    "Current_Year_GP", 
    "Prior_Year_GP"
]

# Generate sum expressions dynamically
sum_expressions = [_sum(col(c)).alias(f"Total_{c}") for c in columns_to_sum]

# Create a new column with the fiscal year value in in to a new column
df = df.withColumn("Scenario_FYXX", col("Scenario").substr(1, 4))

# Perform conditional aggregation on df for internal
df_internal = (df
      .filter(col("Internal_External") == "Internal")
      .groupBy(*group_columns)
      .agg(*sum_expressions)
      .withColumn("Internal_External", lit("Internal"))  # TODO: need to remove this and double check
      )

# Perform conditional aggregation on df for external
df_external = (df
      .groupBy(*group_columns)
      .agg(*sum_expressions)
      .withColumn("Internal_External", lit("External"))
      )

# COMMAND ----------

# DBTITLE 1,Calculate KPI's for Value
# Needed columns from dataframe for value kpi calculations
selected_columns_value_kpi = [
  "Time", 
  "Scenario_FYXX", 
  "Organization", 
  "Account", 
  "Scenario_lv_2", 
  "Flag", 
  "Internal_External", 
  "Total_Value"
]

# Needed columns from dataframe for value_ya kpi calculations
selected_columns_value_ya_kpi = [
  "Time", 
  "Scenario_FYXX", 
  "Organization", 
  "Account", 
  "Scenario_lv_2", 
  "Flag", 
  "Internal_External", 
  "Total_Value_YA"
]

# Specify the columns to group by for pivot table
pivot_group_columns = [
    "Time", 
    "Scenario_FYXX", 
    "Organization", 
    "Scenario_lv_2",
    "Flag",
    "Internal_External"
]

# Pivot the table and perform percentage calculations 
pivot_df_internal_value = (df_internal
                           .select(*selected_columns_value_kpi)
                           .groupBy(*pivot_group_columns)
                           .pivot("Account")
                           .agg(sum("Total_Value").alias("Total_Value"))
                          )

pivot_df_internal_value_ya = (df_internal
                           .select(*selected_columns_value_ya_kpi)
                           .groupBy(*pivot_group_columns)
                           .pivot("Account")
                           .agg(sum("Total_Value_YA").alias("Total_Value_YA"))
                          )

pivot_df_external_value = (df_external
                           .select(*selected_columns_value_kpi)
                           .groupBy(*pivot_group_columns)
                           .pivot("Account")
                           .agg(sum("Total_Value").alias("Total_Value"))
                          )

pivot_df_external_value_ya = (df_external
                           .select(*selected_columns_value_ya_kpi)
                           .groupBy(*pivot_group_columns)
                           .pivot("Account")
                           .agg(sum("Total_Value_YA").alias("Total_Value_YA"))
                          )
  

# Apply each calculation with dynamic column naming
pivot_df_internal_value = add_percentage_columns(pivot_df_internal_value, percentage_columns, "Internal")
pivot_df_internal_value_ya = add_percentage_columns(pivot_df_internal_value_ya, percentage_columns, "Internal")
pivot_df_external_value = add_percentage_columns(pivot_df_external_value, percentage_columns, "External")
pivot_df_external_value_ya = add_percentage_columns(pivot_df_external_value_ya, percentage_columns, "External")

# Generate the list of columns to unpivot. one for external and one ofr internal
accounts_internals = [col for col in pivot_df_internal_value.columns if col not in pivot_group_columns]
accounts_externals = [col for col in pivot_df_external_value.columns if col not in pivot_group_columns]

# Generate the stack expression
stack_expression_internals = generate_stack_expression(accounts_internals)
stack_expression_externals = generate_stack_expression(accounts_externals)

# Combine the column names with the complex expression
all_expressions_internals =  pivot_group_columns + [stack_expression_internals]
all_expressions_externals =  pivot_group_columns + [stack_expression_externals]

# Unpivot the dataframes
unpivot_df_internal_value = pivot_df_internal_value.selectExpr(*all_expressions_internals)
unpivot_df_internal_value_ya = (pivot_df_internal_value_ya
                                .selectExpr(*all_expressions_internals)
                                .withColumnRenamed("Value", "Value_YA")
                                )
unpivot_df_external_value = pivot_df_external_value.selectExpr(*all_expressions_externals)
unpivot_df_external_value_ya = (pivot_df_external_value_ya
                                .selectExpr(*all_expressions_externals)
                                .withColumnRenamed("Value", "Value_YA")
                                )

## Join Value and Value_YA dataframes to generate one internal and one external dataframes
#Join condition
condition = (
    (col("df.Time") == col("df_other.Time")) &
    (col("df.Scenario_FYXX") == col("df_other.Scenario_FYXX")) &
    (col("df.Organization") == col("df_other.Organization")) &
    (col("df.Scenario_lv_2") == col("df_other.Scenario_lv_2")) &
    (col("df.Flag") == col("df_other.Flag")) &
    (col("df.Internal_External") == col("df_other.Internal_External")) &
    (col("df.Account") == col("df_other.Account")) 
)

#List of calculated internal and external dataframe columns
calculated_df_columns = ["df." + column for column in unpivot_df_internal_value.columns] + ["df_other.Value_YA"]

# Generate calculated internal dataframe
calculated_df_internal = (unpivot_df_internal_value.alias("df")
                          .join(unpivot_df_internal_value_ya.alias("df_other"), condition, "left")
                          .select(*calculated_df_columns)
                      )

# Generate calculated external dataframe
calculated_df_external = (unpivot_df_external_value.alias("df")
                          .join(unpivot_df_external_value_ya.alias("df_other"), condition, "left")
                          .select(*calculated_df_columns)
                      )

# COMMAND ----------

# DBTITLE 1,Join and add sumed columns
#Join condition
summed_join_condition = (
    (col("df.Time") == col("df_other.Time")) &
    (col("df.Scenario_FYXX") == col("df_other.Scenario_FYXX")) &
    (col("df.Organization") == col("df_other.Organization")) &
    (col("df.Scenario_lv_2") == col("df_other.Scenario_lv_2")) &
    (col("df.Flag") == col("df_other.Flag")) &
    (col("df.Internal_External") == col("df_other.Internal_External"))
)

#List of calculated internal and external dataframe columns
include_columns = [
  "df_other.Total_Current_Year_NCS", 
  "df_other.Total_Prior_Year_NCS",
  "df_other.Total_Current_Year_GP",
  "df_other.Total_Prior_Year_GP"
]

df_columns = ["df." + column for column in calculated_df_internal.columns] + include_columns

# Generate internal dataframe
final_df_internal = (calculated_df_internal.alias("df")
                     .join(df_internal.alias("df_other"), summed_join_condition, "left")
                     .select(*df_columns)
                     .dropDuplicates()
                    )

# Generate external dataframe
final_df_external = (calculated_df_external.alias("df")
                     .join(df_external.alias("df_other"), summed_join_condition, "left")
                     .select(*df_columns)
                     .dropDuplicates()
                    )

# COMMAND ----------

# DBTITLE 1,Partition and remove unwanted records
columns_to_check = ["Time", "Scenario_FYXX", "Organization", "Scenario_lv_2", "Flag", "Internal_External", "Account"]

# Define a window spec to count occurrences over the specified columns
windowSpec = Window.partitionBy(columns_to_check)

# Define a window spec partitioned by the duplicate columns and ordered by some column that can provide uniqueness
windowSpec = Window.partitionBy(columns_to_check).orderBy(*columns_to_check)

# Add a row number within each partition of duplicates
final_df_internal_with_row_number = final_df_internal.withColumn('row_number', row_number().over(windowSpec))
final_df_external_with_row_number = final_df_external.withColumn('row_number', row_number().over(windowSpec))

# Filter out one of the duplicates by keeping rows where the row number is 1
df_filtered_internal = final_df_internal_with_row_number.filter('row_number = 1').drop('row_number')
df_filtered_external = final_df_external_with_row_number.filter('row_number = 1').drop('row_number')

# COMMAND ----------

# DBTITLE 1,Generate Final Dataframe
# Union two dataframes
result_df = df_filtered_internal.union(df_filtered_external)

# # Filter all null value rows for value column
# result_df = result_df.filter(col("Value").isNotNull())

# Add curated_processdatetime column
result_df = result_df.withColumn("refined_processdatetime",lit(process_datetime).cast(TimestampType())) 

# Rename column definitions 
result_df = rename_columns(result_df, rename_column_definition)

# # Apply column definitions
# result_df = apply_column_definitions(result_df, column_definition)

# COMMAND ----------

# DBTITLE 1,Write to Delta
#Columns needed for insering unique records
unique_columns = ["Time", "Organization", "Scenario", "Account", "Flag", "Internal_External"]

records_inserted = delta_merge_insert_records(result_df, destination_table_name, destination_path, unique_columns)

# Create database if not exist
create_database_if_not_exist(db_name)

# Create table if not exist
create_table_if_not_exist(destination_table_name, destination_path)

# COMMAND ----------

# DBTITLE 1,Write to Sql DB
# Read entire dataframe
total_df = spark.table(destination_table_name)

# sql db table names
sql_table_name = parameters["Sink"]["sink"]["sqlTableName"]

# Write to sql server db
write_df_to_sql_server(total_df, sql_table_name, mode = "overwrite")

# COMMAND ----------

# DBTITLE 1,Exit Notebook
valuesToReturn = {
  "delta_rows_inserted": records_inserted, 
  "message_count":df_message_count,
  "sql_rows_inserted":total_df.count()
}

dbutils.notebook.exit(valuesToReturn)
