# Databricks notebook source
# MAGIC %md
# MAGIC #Overview
# MAGIC
# MAGIC | Detail Tag | Information |
# MAGIC | -------- | ------- |
# MAGIC | Description | To run this notebook, please copy and paste source and sink parameters to the widget's box in this notebook. </br> </br> Make sure to run the cell in the notebook with the `get_curated_notebook_widgets()` function to display the widgets.</br> </br> Additional documentation regarding this notebook is in the pipeline documentation page. |
# MAGIC | Source Parameter |  `source = {"inputTable": "raw.actuals"}` |
# MAGIC | Sink Parameter |    <code>sink = { "sink":{"outputFilePath":"/mnt/clx-datalake/finance/curated/essbase/actuals",<br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp"tableName":"curated.actuals",<br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp"sqlTableName":"dbo.curated_actuals"}<br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp}</code>|

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import col, max, regexp_extract, trim, expr, concat, cast, upper
from pyspark.sql.types import StructType, StructField, StringType, DoubleType


# COMMAND ----------

# DBTITLE 1,Load Common Libraries
# MAGIC %run ../lib/common

# COMMAND ----------

# DBTITLE 1,Create curated notebook widgets
get_curated_notebook_widgets()

# COMMAND ----------

# DBTITLE 1,Get curated parameters
parameters = get_curated_parameters()

# COMMAND ----------

# DBTITLE 1,Definition
# schema_definition = StructType([
#     StructField("Time", StringType(), True),
#     StructField("Organization", StringType(), True),
#     StructField("Scenario", StringType(), True),
#     StructField("Account", StringType(), True),
#     StructField("Value", DoubleType(), True)
# ])


# Values to exclude from account column in the dataframe
values_to_exclude = [
    "Gross Margin",
    "COGS / SC ($)",
    "Gross Profit / SC",
    "NCS / SC ($)",
    "Red Rev % of NCS",
    "EBIT Margin",
    "Operating Profit Margin",
    "Pretax Profit Margin",
    "SBU EBIT Margin",
    "SBU Profit Margin",
    "Total Adv. & SP % of NCS",
    "Total Selling & Admin % of NCS"
]

# COMMAND ----------

# DBTITLE 1,Parameters
#get processed datetime
process_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# get Source parameters
input_table = parameters["Source"]["inputTable"]

# get Sink parameters
destination_path = parameters["Sink"]["sink"]["outputFilePath"]
destination_table_name = parameters["Sink"]["sink"]["tableName"]

db_name = destination_table_name.split(".")[0]

# COMMAND ----------

# DBTITLE 1,Read Delta
df = spark.read.table(input_table)

# Get total message count
df_message_count = df.count()

# COMMAND ----------

# DBTITLE 1,Get  previous high watermark
previous_high_watermark = df.agg({"processdatetime": "max"}).collect()[0][0]

df = df.where(col("processdatetime").between(previous_high_watermark, process_datetime))

# COMMAND ----------

# DBTITLE 1,Processing
# Remove all duplicate rows
df = df.dropDuplicates()

# Read Senario table
df_scenario = spark.table("reference.scenario")

#Get high watermark value for scenario table 
#Select only needed columns from scenario table
scenario_high_watermark = df_scenario.agg({"processdatetime": "max"}).collect()[0][0]
df_scenario  = (df_scenario
                .where(col("processdatetime").between(scenario_high_watermark, process_datetime))
                .select(['Scenario_lv_1', 'Scenario_lv_2', 'Flag', 'Internal/External'])
                .withColumn("Scenario_lv_1", upper(col("Scenario_lv_1")))
              )

# Filtering out the rows with exclude account values
df = df.filter(~col("Account").isin(values_to_exclude))

#Create temp column with substring of scenario column, merge with scenario dataframe 
df = (df
      .withColumn("Scenario_Temp", regexp_extract(col("Scenario"), ".{4}(.*)", 1))
      .withColumn("Scenario_Temp", trim(col("Scenario_Temp")))
      .withColumn("Scenario_Temp", upper(col("Scenario_Temp")))
    )
  
df = (df
      .join(df_scenario, df.Scenario_Temp == df_scenario.Scenario_lv_1, "left")
      .drop(*[col("Scenario_lv_1"), col("Scenario_Temp")])
    )

#Create Value_YA column
# Increment the fiscal year within the string by plus 1
df_shifted_by_year = (df.withColumn("year", regexp_extract("Scenario", "FY(\\d+)", 1).cast("int"))  # Extract and cast year
                        .withColumn("year_incremented", col("year") + 1)  # Increment year
                        .withColumn("rest_of_string", regexp_extract("Scenario", "FY\\d+ (.+)", 1)) # Extract the rest of the string
                        .withColumn("Scenario_incremented", 
                                    expr("concat('FY', cast(year_incremented as string), ' ', rest_of_string)")) # Reconstruct the string
                        .withColumnRenamed("Value", "Value_YA") # Update the name to value_ya
                        .select('Time'
                                , 'Organization'
                                , 'Scenario_incremented'
                                , 'Account'
                                , 'Scenario_lv_2'
                                , 'Flag'
                                , 'Internal/External'
                                , 'Value_YA'
                                ) # Select only the following columns for the final dataframe to return
                    )

#Add Value_YA to df by joining to df_shifted_by_year dataframe
value_ya_condition = (
    (col("df.Time") == col("df_shifted_by_year.Time")) &
    (col("df.Organization") == col("df_shifted_by_year.Organization")) &
    (col("df.Scenario") == col("df_shifted_by_year.Scenario_incremented")) &
    (col("df.Account") == col("df_shifted_by_year.Account")) &
    (col("df.Scenario_lv_2") == col("df_shifted_by_year.Scenario_lv_2")) &
    (col("df.Flag") == col("df_shifted_by_year.Flag")) &
    (col("df.`Internal/External`") == col("df_shifted_by_year.`Internal/External`")) 
)

#List of final dataframe columns
value_ya_df_columns = ["df." + column for column in df.columns] + ["df_shifted_by_year.Value_YA"]

df = (df.alias("df")
      .join(df_shifted_by_year.alias("df_shifted_by_year"), value_ya_condition, "left")
      .select(*value_ya_df_columns)
    )

#Join back to main dataframe to add curr year and prior year ncs columns
condition = (
    (col("df.Time") == col("df_other.Time")) &
    (col("df.Organization") == col("df_other.Organization")) &
    (col("df.Scenario") == col("df_other.Scenario")) &
    (col("df.Scenario_lv_2") == col("df_other.Scenario_lv_2")) &
    (col("df.Flag") == col("df_other.Flag")) &
    (col("df.`Internal/External`") == col("df_other.`Internal/External`")) 
)

#Add curr and prior year sales column
df_ncs = (df
          .filter(col("Account") == "Net Customer Sales")
          .withColumnRenamed("Value", "Current_Year_NCS")
          .withColumnRenamed("Value_YA", "Prior_Year_NCS")
          )

#List of final dataframe columns          
ncs_df_columns = ["df." + column for column in df.columns] + ["df_other.Current_Year_NCS", "df_other.Prior_Year_NCS"]

df = (df.alias("df")
      .join(df_ncs.alias("df_other"), condition, "left")
      .select(*ncs_df_columns)
    )

#Add curr and prior year gross profit column
df_gp = (df
          .filter(col("Account") == "Gross Profit")
          .withColumnRenamed("Value", "Current_Year_GP")
          .withColumnRenamed("Value_YA", "Prior_Year_GP")
      )

#List of final dataframe columns          
gp_df_columns = ["df." + column for column in df.columns] + ["df_other.Current_Year_GP", "df_other.Prior_Year_GP"]

df = (df.alias("df")
      .join(df_gp.alias("df_other"), condition, "left")
      .select(*gp_df_columns)
    )

df = df.withColumnRenamed("Internal/External", "Internal_External")

# COMMAND ----------

# DBTITLE 1,Write to Delta
#Columns needed for insering unique records
unique_columns = ["Time", "Organization", "Scenario", "Account", "Value", "filepath", "processdatetime"]

#Add curated_processdatetime column
df = df.withColumn("curated_processdatetime",lit(process_datetime).cast(TimestampType()))     

records_inserted = delta_merge_insert_records(df, destination_table_name, destination_path, unique_columns)

# Create database if not exist
create_database_if_not_exist(db_name)

# Create table if not exist
create_table_if_not_exist(destination_table_name, destination_path)

# COMMAND ----------

# DBTITLE 1,Write to Sql DB
# Read entire dataframe
total_df = spark.table(destination_table_name)

# sql db table names
sql_table_name = parameters["Sink"]["sink"]["sqlTableName"]

# Write to sql server db
write_df_to_sql_server(total_df, sql_table_name, mode = "overwrite")

# COMMAND ----------

# DBTITLE 1,Exit Notebook
valuesToReturn = {
  "delta_rows_inserted": records_inserted, 
  "message_count":df_message_count,
  "sql_rows_inserted":total_df.count()
}

dbutils.notebook.exit(valuesToReturn)
