# Databricks notebook source
import ast
import json


# COMMAND ----------

# MAGIC %run ../lib/functions

# COMMAND ----------

# DBTITLE 1,Run Actuals Curated
# Set parameters 
notebook_path="../essbase/essbase_curated"

source=json.dumps({
          "inputTable": "raw.actuals"
            })

sink=json.dumps({
    "sink": {
          "outputFilePath":"/mnt/clx-datalake/finance/curated/essbase/actuals", 
          "tableName":"curated.actuals",
          "sqlTableName":"dbo.curated_actuals"  
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="curated", 
  load_type="overwrite"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Run Forecast Curated
# Set parameters 
notebook_path="../essbase/essbase_curated"

source=json.dumps({
          "inputTable": "raw.forecast"
            })

sink=json.dumps({
    "sink": {
              "outputFilePath":"/mnt/clx-datalake/finance/curated/essbase/forecast", 
              "tableName":"curated.forecast",
              "sqlTableName":"dbo.curated_forecast"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="curated", 
  load_type="overwrite"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Driver Actuals Bucket
# Set parameters 
notebook_path="../driver/driver_actuals_bucket_curated"

source=json.dumps({
          "inputTable": "raw.driver_actuals_bucket"
            })

sink=json.dumps({
    "sink": {
            "outputFilePath":"/mnt/clx-datalake/finance/curated/driver/actuals/bucket", 
            "tableName":"curated.driver_actuals_bucket",
            "sqlTableName":"dbo.curated_driver_actuals_bucket"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="curated", 
  load_type="overwrite"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])
