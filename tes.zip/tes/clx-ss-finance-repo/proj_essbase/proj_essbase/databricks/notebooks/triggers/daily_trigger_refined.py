# Databricks notebook source
import ast
import json


# COMMAND ----------

# MAGIC %run ../lib/functions

# COMMAND ----------

# DBTITLE 1,Run Actuals Refined
# Set parameters 
notebook_path="../essbase/essbase_refined"

source=json.dumps({
          "inputTable": "curated.actuals"
            })

sink=json.dumps({
    "sink": {
          "outputFilePath":"/mnt/clx-datalake/finance/refined/essbase/actuals", 
          "tableName":"refined.actuals",
          "sqlTableName":"dbo.refined_actuals"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="refined", 
  load_type="overwrite"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Run Forecast Refined
# Set parameters 
notebook_path="../essbase/essbase_refined"

source=json.dumps({
          "inputTable": "curated.forecast"
            })

sink=json.dumps({
    "sink": {
              "outputFilePath":"/mnt/clx-datalake/finance/refined/essbase/forecast", 
              "tableName":"refined.forecast",
              "sqlTableName":"dbo.refined_forecast"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="refined", 
  load_type="overwrite"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])
