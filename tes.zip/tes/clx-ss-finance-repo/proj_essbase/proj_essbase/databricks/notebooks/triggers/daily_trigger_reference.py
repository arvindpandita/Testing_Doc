# Databricks notebook source
import ast
import json


# COMMAND ----------

# MAGIC %run ../lib/functions

# COMMAND ----------

# DBTITLE 1,Run Time Reference
# Set parameters 
notebook_path="../reference/time_reference"

source=json.dumps({
                    "inputFilePath":"/mnt/clx-datalake/finance/landing/reference/time/"
                  , "sheetName":"Time"
                  , "data_address":"'Time'!A1"
                  , "enableFileTracker": "False"
            })

sink=json.dumps({
    "sink": {
        "outputFilePath":"/mnt/clx-datalake/finance/reference/time", 
        "tableName":"reference.time",
        "sqlTableName":"dbo.reference_time"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="reference", 
  load_type="overwrite"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Run Scenario Reference
# Set parameters 
notebook_path="../reference/scenario_reference"

source=json.dumps({
                  "inputFilePath":"/mnt/clx-datalake/finance/landing/reference/scenario"
                  , "sheetName":"Scenario"
                  , "data_address":"'Scenario'!A1"
                  , "enableFileTracker": "False"
        })

sink=json.dumps({
    "sink":{
              "outputFilePath":"/mnt/clx-datalake/finance/reference/scenario", 
              "tableName":"reference.scenario",
              "sqlTableName":"dbo.reference_scenario"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="reference", 
  load_type="overwrite"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Run Account Reference
# Set parameters 
notebook_path="../reference/account_reference"

source=json.dumps({
                    "inputFilePath":"/mnt/clx-datalake/finance/landing/reference/account"
                    , "sheetName":"Account"
                    , "data_address":"'Account'!A1"
                    , "enableFileTracker": "False"
        })

sink=json.dumps({
    "sink":{
              "outputFilePath":"/mnt/clx-datalake/finance/reference/account", 
              "tableName":"reference.account",
              "sqlTableName":"dbo.reference_account"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="reference", 
  load_type="overwrite"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Run Comparison Reference
# Set parameters 
notebook_path="../reference/comparison_reference"

source=json.dumps({
              "inputFilePath":"/mnt/clx-datalake/finance/landing/reference/comparison"
                , "sheetName":"Comparison"
                , "data_address":"'Comparison'!A1"
                , "enableFileTracker": "False"
        })

sink=json.dumps({
    "sink":{
              "outputFilePath":"/mnt/clx-datalake/finance/reference/comparison", 
              "tableName":"reference.comparison",
              "sqlTableName":"dbo.reference_comparison"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="reference", 
  load_type="overwrite"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Run Orgnization Reference
# Set parameters 
notebook_path="../reference/organization_reference"

source=json.dumps({
              "inputFilePath":"/mnt/clx-datalake/finance/landing/reference/organization"
                , "sheetName":"Organization"
                , "data_address":"'Organization'!A1"
                , "enableFileTracker": "False"
        })

sink=json.dumps({
    "sink":{
            "outputFilePath":"/mnt/clx-datalake/finance/reference/organization", 
            "tableName":"reference.organization",
            "sqlTableName":"dbo.reference_organization"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="reference", 
  load_type="overwrite"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])
