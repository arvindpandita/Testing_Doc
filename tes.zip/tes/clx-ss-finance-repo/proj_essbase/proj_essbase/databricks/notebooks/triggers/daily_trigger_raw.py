# Databricks notebook source
import ast
import json

# COMMAND ----------

# MAGIC %run ../lib/functions

# COMMAND ----------

# DBTITLE 1,Essbase Actuals Raw
# Set parameters 
notebook_path = "../essbase/essbase_raw"

source = json.dumps({   
                     "inputFilePath":"/mnt/clx-datalake/finance/landing/essbase/actuals"
                    , "sheetName": "in"
                    , "data_address": "'in'!A1"
                    , "enableFileTracker": "True" 
                })

sink = json.dumps({"sink": {
                      "outputFilePath":"/mnt/clx-datalake/finance/raw/essbase/actuals", 
                      "tableName":"raw.actuals",
                      "sqlTableName":"dbo.raw_actuals"
                        }
                    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="raw", 
  load_type="append"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Essbase Forecast Raw

# Set parameters 
notebook_path = "../essbase/essbase_raw"

source = json.dumps({
                  "inputFilePath":"/mnt/clx-datalake/finance/landing/essbase/forecast"
                  , "sheetName": "in"
                  , "data_address": "'in'!A1"
                  , "enableFileTracker": "True" 
                })

sink = json.dumps({
                "sink": {
                  "outputFilePath":"/mnt/clx-datalake/finance/raw/essbase/forecast", 
                  "tableName":"raw.forecast",
                  "sqlTableName":"dbo.raw_forecast"
                }
            })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="raw", 
  load_type="append"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Driver Actuals Raw Bucket

# Set parameters 
notebook_path="../driver/driver_actuals_bucket_raw"

source=json.dumps({
        "inputFilePath": "/mnt/clx-datalake/finance/landing/driver/actuals/bucket"
        , "sheetName": "Data - Bucket"
        , "data_address": "'Data - Bucket'!B2"
        , "enableFileTracker": "True"
        })

sink=json.dumps({
        "sink": {
              "outputFilePath":"/mnt/clx-datalake/finance/raw/driver/actuals/bucket", 
              "tableName":"raw.driver_actuals_bucket",
              "sqlTableName":"dbo.raw_driver_actuals_bucket"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="raw", 
  load_type="append"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Driver Actuals Raw Volume
# Set parameters 
notebook_path="../driver/driver_actuals_volume_raw"

source=json.dumps({
        "inputFilePath": "/mnt/clx-datalake/finance/landing/driver/actuals/volume"
        , "sheetName":"Data - Volume"
        , "data_address":"'Data - Volume'!B2"
        , "enableFileTracker": "True"
        })

sink=json.dumps({
        "sink": {
              "outputFilePath":"/mnt/clx-datalake/finance/raw/driver/actuals/volume", 
              "tableName":"raw.driver_actuals_volume",
              "sqlTableName":"dbo.raw_driver_actuals_volume"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="raw", 
  load_type="append"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Driver Actuals Raw Story
#Set parameters 
notebook_path="../driver/driver_actuals_data_story_raw"

source=json.dumps({
        "inputFilePath": "/mnt/clx-datalake/finance/landing/driver/actuals/story"
        , "sheetName":"Data - Story"
        , "data_address":"'Data - Story'!B2"
        , "enableFileTracker": "True"
        })

sink=json.dumps({
        "sink": {
              "outputFilePath":"/mnt/clx-datalake/finance/raw/driver/actuals/story", 
              "tableName":"raw.driver_actuals_story",
              "sqlTableName":"dbo.raw_driver_actuals_story"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="raw", 
  load_type="append"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Driver Actuals Raw summary
#Set parameters 
notebook_path="../driver/driver_actuals_exec_summary_raw"

source=json.dumps({
        "inputFilePath": "/mnt/clx-datalake/finance/landing/driver/actuals/exec_summary"
        , "sheetName":"Data - Exec Summary"
        , "data_address":"'Data - Exec Summary'!B2"
        , "enableFileTracker": "True"
        })

sink=json.dumps({
        "sink": {
              "outputFilePath":"/mnt/clx-datalake/finance/raw/driver/actuals/summary", 
              "tableName":"raw.driver_actuals_summary",
              "sqlTableName":"dbo.raw_driver_actuals_summary"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="raw", 
  load_type="append"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Driver Forecast Raw Bucket
#Set parameters 
notebook_path="../driver/driver_forecast_bucket_raw"

source=json.dumps({
        "inputFilePath": "/mnt/clx-datalake/finance/landing/driver/forecast/bucket"
        , "sheetName": "Data - Bucket"
        , "data_address": "'Data - Bucket'!B2"
        , "enableFileTracker": "True"
        })

sink=json.dumps({
        "sink": {
              "outputFilePath":"/mnt/clx-datalake/finance/raw/driver/forecast/bucket", 
              "tableName":"raw.driver_forecast_bucket",
              "sqlTableName":"dbo.raw_driver_forecast_bucket"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="raw", 
  load_type="append"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])

# COMMAND ----------

# DBTITLE 1,Driver Forecast Raw Story
#Set parameters 
notebook_path="../driver/driver_forecast_data_story_raw"

source=json.dumps({
        "inputFilePath": "/mnt/clx-datalake/finance/landing/driver/forecast/story"
        , "sheetName":"Data - Story"
        , "data_address":"'Data - Story'!B2"
        , "enableFileTracker": "True"
        })

sink=json.dumps({
        "sink": {
              "outputFilePath":"/mnt/clx-datalake/finance/raw/driver/forecast/story", 
              "tableName":"raw.driver_forecast_story",
              "sqlTableName":"dbo.raw_driver_forecast_story"
        }
    })

#Run notebook
run_status_dict = run_notebook(notebook_path, source, sink)

#Add msg to audit table 
apply_audit_log(
  run_status_dict, 
  source=source,
  sink=sink,
  notebook_path=notebook_path,
  phase="raw", 
  load_type="append"
)

#Fail the cell if run_status is failed
if run_status_dict["run_status"] == "Failed":
   raise CustomException(run_status_dict["error_msg"])
