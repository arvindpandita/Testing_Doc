# Databricks notebook source
import unittest

# COMMAND ----------

# DBTITLE 1,Load Integration Test
# MAGIC %run ./driver/driver_actuals_bucket_curated_IntegrationTest

# COMMAND ----------

# DBTITLE 1,Run Integration Test
suite = unittest.TestLoader().loadTestsFromTestCase(driver_actuals_bucket_curated_IntegrationTest)
runner = unittest.TextTestRunner(verbosity=2)
results = runner.run(suite)
print(results)

# COMMAND ----------


