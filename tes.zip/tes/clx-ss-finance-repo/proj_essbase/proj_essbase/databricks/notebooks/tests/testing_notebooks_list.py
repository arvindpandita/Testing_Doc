# Databricks notebook source
# DBTITLE 1,Load Common Libraries
# MAGIC %run ../lib/common

# COMMAND ----------

# DBTITLE 1,Load raw integration test classes
# MAGIC %run ./driver/driver_actuals_bucket_raw_IntegrationTest

# COMMAND ----------

# MAGIC %run ./driver/driver_actuals_summary_raw_IntegrationTest

# COMMAND ----------

# MAGIC %run ./driver/driver_actuals_volume_raw_IntegrationTest

# COMMAND ----------

# MAGIC %run ./driver/driver_actuals_story_raw_IntegrationTest

# COMMAND ----------

# MAGIC %run ./driver/driver_forecast_bucket_raw_IntegrationTest

# COMMAND ----------

# MAGIC %run ./driver/driver_forecast_story_raw_IntegrationTest

# COMMAND ----------

# MAGIC %run ./essbase/actuals_raw_IntegrationTest

# COMMAND ----------

# MAGIC %run ./essbase/forecast_raw_IntegrationTest

# COMMAND ----------

# DBTITLE 1,Load Reference Test Classes
# MAGIC %run ./reference/reference_account_IntegrationTest

# COMMAND ----------

# MAGIC %run ./reference/reference_comparison_IntegrationTest

# COMMAND ----------

# MAGIC %run ./reference/reference_organization_IntegrationTest

# COMMAND ----------

# MAGIC %run ./reference/reference_scenario_IntegrationTest

# COMMAND ----------

# MAGIC %run ./reference/reference_time_IntegrationTest

# COMMAND ----------

# DBTITLE 1,Load Curated Tests
# MAGIC %run ./essbase/actuals_curated_IntegrationTest

# COMMAND ----------

# MAGIC %run ./essbase/forecast_curated_IntegrationTest

# COMMAND ----------

# MAGIC %run ./driver/driver_actuals_bucket_curated_IntegrationTest

# COMMAND ----------

# DBTITLE 1,Load Refined Tests
# MAGIC %run ./essbase/forecast_refined_IntegrationTest

# COMMAND ----------

# MAGIC %run ./essbase/actuals_refined_IntegrationTest

# COMMAND ----------


