# Databricks notebook source
# MAGIC %run ../base

# COMMAND ----------

class forecast_refined_IntegrationTest(BaseTesting):

    @classmethod
    def setUpClass(cls):

        # Call the setUpClass of the base class
        super(forecast_refined_IntegrationTest, cls).setUpClass()

        # Set database and table name
        cls.database_name = "refined_test"
        cls.table_name = "refined_test.essbase_forecast"
        cls.sql_table_name = "dbo.test_refined_essbase_forecast"

        # Drop the table and database if they exist
        cls.spark.sql(f"DROP Table IF EXISTS {cls.table_name}")
        # cls.spark.sql(f"DROP Database IF EXISTS {cls.database_name}")

        cls.input_path = "/mnt/clx-datalake/finance/testing/essbase/refined/forecast/part-00000-0304aa1b-70b9-4e29-9c11-c6f04497c1fb.c000.snappy.parquet"
        cls.temp_output_path = f"/mnt/clx-datalake/finance/tmp/integrationtesting/{cls.curr_timestamp}/forecast_refined"

        # Read the data into a DataFrame
        cls.df = spark.read.format("parquet") .load(cls.input_path)
                  
        # Create a temporary view
        cls.df.createOrReplaceGlobalTempView("test_refined_essbase_forecast_view")

        # Setup arguments for target notebook
        cls.arguments = {
            "source": json.dumps({
                "inputTable": "global_temp.test_refined_essbase_forecast_view"
                }),
            "sink": json.dumps({
                "sink": {
                    "outputFilePath": cls.temp_output_path,
                    "tableName": cls.table_name,
                    "sqlTableName": cls.sql_table_name
                }
            })
        }

        # Run the notebook and store the result
        try:
            cls.result = ast.literal_eval(dbutils.notebook.run("../essbase/essbase_refined", 0, cls.arguments))
        except Exception as e:
            cls.result = {"error": str(e)}

        # Read the output sql table
        cls.sql_table_count = spark.read.jdbc(url=cls.jdbcUrl, table= cls.sql_table_name, properties=cls.connectionProperties).count()

    
    @classmethod
    def tearDownClass(cls):
        # Call the tearDownClass of the base testing class
        super(forecast_refined_IntegrationTest, cls).tearDownClass()


    def test_forecast_refined_table_records_inserted_count(self):
        expected_count = 287280
        actual_count = self.result.get("delta_rows_inserted", 0)
        self.assertEqual(actual_count, expected_count, "Record inserted count mismatch.")

    def test_forecast_refined_table_message_count(self):
        expected_count = 22515
        actual_count = self.result.get("message_count", 0)
        self.assertEqual(actual_count, expected_count, "Message count mismatch.")

    def test_forecast_refined_sql_table_records_count(self):
        expected_count = 287280
        actual_count = self.sql_table_count
        self.assertEqual(actual_count, expected_count, "Message count from sql table mismatch.")



# COMMAND ----------


