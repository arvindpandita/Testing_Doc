# Databricks notebook source
# MAGIC %run ../base

# COMMAND ----------

class driver_actuals_bucket_curated_IntegrationTest(BaseTesting):

    @classmethod
    def setUpClass(cls):

        # Call the setUpClass of the base class
        super(driver_actuals_bucket_curated_IntegrationTest, cls).setUpClass()

        # Set database and table name
        cls.database_name = "curated_test"
        cls.table_name = "curated_test.driver_actuals_bucket"
        cls.sql_table_name = "dbo.test_curated_driver_actuals_bucket"

        # Drop the table and database if they exist
        cls.spark.sql(f"DROP Table IF EXISTS {cls.table_name}")
        # cls.spark.sql(f"DROP Database IF EXISTS {cls.database_name}")

        cls.input_path = "/mnt/clx-datalake/finance/testing/driver/curated/bucket/part-00000-052fa7bc-8af2-4ac9-8315-5c9c5e907662.c000.snappy.parquet"
        cls.temp_output_path = f"/mnt/clx-datalake/finance/tmp/integrationtesting/{cls.curr_timestamp}/driver_actuals_bucket"

        # Read the data into a DataFrame
        cls.df = spark.read.format("parquet") .load(cls.input_path)
                  
        # Create a temporary view
        cls.df.createOrReplaceGlobalTempView("test_curated_driver_actuals_bucket_view")

        # Setup arguments for target notebook
        cls.arguments = {
            "source": json.dumps({
                "inputTable": "global_temp.test_curated_driver_actuals_bucket_view"
                }),
            "sink": json.dumps({
                "sink": {
                    "outputFilePath": cls.temp_output_path,
                    "tableName": cls.table_name,
                    "sqlTableName": cls.sql_table_name
                }
            })
        }

        # Run the notebook and store the result
        try:
            cls.result = ast.literal_eval(dbutils.notebook.run("../driver/driver_actuals_bucket_curated", 0, cls.arguments))
        except Exception as e:
            cls.result = {"error": str(e)}

        # Read the output sql table
        cls.sql_table_count = spark.read.jdbc(url=cls.jdbcUrl, table= cls.sql_table_name, properties=cls.connectionProperties).count()

    
    @classmethod
    def tearDownClass(cls):
        # Call the tearDownClass of the base testing class
        super(driver_actuals_bucket_curated_IntegrationTest, cls).tearDownClass()


    def test_driver_actuals_bucket_curated_table_records_inserted_count(self):
        expected_count = 759
        actual_count = self.result.get("delta_rows_inserted", 0)
        self.assertEqual(actual_count, expected_count, "Record inserted count mismatch.")

    def test_driver_actuals_bucket_curated_table_message_count(self):
        expected_count = 382
        actual_count = self.result.get("message_count", 0)
        self.assertEqual(actual_count, expected_count, "Message count mismatch.")

    def test_driver_actuals_bucket_curated_sql_table_records_count(self):
        expected_count = 759
        actual_count = self.sql_table_count
        self.assertEqual(actual_count, expected_count, "Message count from sql table mismatch.")


