# Databricks notebook source
import ast
import json
import unittest
import shutil
from datetime import datetime
from pyspark.sql import SparkSession

# COMMAND ----------

class BaseTesting(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):

        # Initialize Spark session
        cls.spark = SparkSession.builder.appName("IntegrationTests").getOrCreate()

        # Setup tasks common to all tests
        # Set up SQL connection settings
        cls.jdbcUrl = f"jdbc:sqlserver://sql-ssefin-selfserv01.database.windows.net:1433;database=SQLDB-SSEFIN-SELFSERV01;"
        cls.connectionProperties = {
            "user": "SSEDATA_RW",
            "password": dbutils.secrets.get(scope="KV-SSE-SCOPE", key="KV-SSEDATA"),
            "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
        }

        # Get the current timestamp
        cls.curr_timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    
    @classmethod
    def tearDownClass(cls):
        # Teardown tasks common to all tests
        # Delete all files in the directory
        files = dbutils.fs.ls(cls.temp_output_path)
        for file in files:
            dbutils.fs.rm(file.path, recurse=True)

        # Delete the directory itself
        dbutils.fs.rm(cls.temp_output_path, recurse=True)

# COMMAND ----------


