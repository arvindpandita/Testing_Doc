# Databricks notebook source
# MAGIC %run ../base

# COMMAND ----------

class driver_actuals_bucket_raw_IntegrationTest(BaseTesting):

    @classmethod
    def setUpClass(cls):

        # Call the setUpClass of the base class
        super(driver_actuals_bucket_raw_IntegrationTest, cls).setUpClass()

        # Set database and table name
        cls.database_name = "raw_test"
        cls.table_name = "raw_test.driver_actuals_bucket"
        cls.sql_table_name = "dbo.test_raw_driver_actuals_bucket"

        # Drop the table and database if they exist
        cls.spark.sql(f"DROP Table IF EXISTS {cls.table_name}")
        # cls.spark.sql(f"DROP Database IF EXISTS {cls.database_name}")

        # Setup file paths and arguments
        cls.input_path = "/mnt/clx-datalake/finance/testing/driver/actuals/bucket/Brita Finance Driver Close_Q1_FY24.xlsm"
        cls.temp_output_path = f"/mnt/clx-datalake/finance/tmp/integrationtesting/{cls.curr_timestamp}/driver_actuals_bucket_raw"

        # Setup arguments for target notebook
        cls.arguments = {
            "source": json.dumps({
                "inputFilePath": cls.input_path,
                "sheetName":"Data - Bucket",
                "data_address":"'Data - Bucket'!B2",
                "enableFileTracker": 'False'
                }),
            "sink": json.dumps({
                "sink": {
                    "outputFilePath": cls.temp_output_path,
                    "tableName": cls.table_name,
                    "sqlTableName": cls.sql_table_name
                }
            })
        }

        # Run the notebook and store the result
        try:
            cls.result = ast.literal_eval(dbutils.notebook.run("../driver/driver_actuals_bucket_raw", 0, cls.arguments))
        except Exception as e:
            cls.result = {"error": str(e)}

        # Read the output sql table
        cls.sql_table_count = spark.read.jdbc(url=cls.jdbcUrl, table= cls.sql_table_name, properties=cls.connectionProperties).count()
    
    @classmethod
    def tearDownClass(cls):
        # Call the tearDownClass of the base testing class
        super(driver_actuals_bucket_raw_IntegrationTest, cls).tearDownClass()
    
    def test_driver_actuals_bucket_raw_table_records_inserted_count(self):
        expected_count = 6122
        actual_count = self.result.get("delta_rows_inserted", 0)
        self.assertEqual(actual_count, expected_count, "Record inserted count mismatch.")

    def test_driver_actuals_bucket_raw_table_message_count(self):
        expected_count = 6122
        actual_count = self.result.get("message_count", 0)
        self.assertEqual(actual_count, expected_count, "Message count mismatch.")

    def test_driver_actuals_bucket_raw_sql_table_records_count(self):
        expected_count = 6122
        actual_count = self.sql_table_count
        self.assertEqual(actual_count, expected_count, "Message count from sql table mismatch.")

