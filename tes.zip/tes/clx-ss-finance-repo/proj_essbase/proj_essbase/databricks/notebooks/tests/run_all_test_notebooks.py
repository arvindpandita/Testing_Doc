# Databricks notebook source
# MAGIC %run ./testing_notebooks_list

# COMMAND ----------

# DBTITLE 1,Load all intergration notebooks
# Initialize Spark Session
spark = SparkSession.builder.appName("IntegrationTestLogging").getOrCreate()

# Initialize logging
delta_table_path = '/mnt/clx-datalake/finance/audit/integration_test_logger'
logger = setup_logging (spark, delta_table_path)

# Get the list of all the testing classes within the global scope
def get_test_classes():
    test_classes = []
    for obj in globals().values():
        if isinstance(obj, type) and issubclass(obj, unittest.TestCase) and obj.__name__.endswith('_IntegrationTest'):
            test_classes.append(obj)
    return list(set(test_classes))
  
# Run all the tests one at a time
def run_tests(test_classes, logger):
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    for test_class in test_classes:
        # logger.info(f"Starting tests in {test_class.__name__}")
        tests = loader.loadTestsFromTestCase(test_class)
        suite.addTests(tests)

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    print(result)

    print(f"Tests run: {result.testsRun}, Failures: {len(result.failures)}, Errors: {len(result.errors)}")

    # logger.info(f"Tests run: {result.testsRun}, Failures: {len(result.failures)}, Errors: {len(result.errors)}")

    return result

# COMMAND ----------

# DBTITLE 1,Run All Tests
test_classes = get_test_classes()
result = run_tests(test_classes, logger)

# COMMAND ----------

#Fail integrtation testing of there are failed tests
if len(result.failures) > 0 or len(result.errors) > 0 :
  raise CustomException(f"Tests run: {result.testsRun}, Failures: {len(result.failures)}, Errors: {len(result.errors)}")

# COMMAND ----------


