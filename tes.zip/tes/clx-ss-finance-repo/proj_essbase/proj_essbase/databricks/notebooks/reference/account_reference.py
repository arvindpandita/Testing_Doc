# Databricks notebook source
# MAGIC %md
# MAGIC #Overview
# MAGIC
# MAGIC | Detail Tag | Information |
# MAGIC | -------- | ------- |
# MAGIC | Description | To run this notebook, please copy and paste source and sink parameters to the widget's box in this notebook. </br> </br> Make sure to run the cell in the notebook with the `get_raw_notebook_widgets()` function to display the widgets. </br> </br> In the source parameter, `enableFileTracker` should be True. If `enableFileTracker` is False, this notebook will load and process all files from the landing zone. </br> </br> Additional documentation regarding this notebook is in the pipeline documentation page. |
# MAGIC | Source Parameter |  <code>{"source":{"inputFilePath": "/mnt/clx-datalake/finance/testing/reference/",<br>&nbsp&nbsp"sheetName": "Account",<br>&nbsp&nbsp"data_address": "'Account'!A1",<br>&nbsp&nbsp"enableFileTracker": "False"}}<code/> |
# MAGIC | Sink Parameter |  <code>{"sink":{"outputFilePath":""/mnt/clx-datalake/finance/reference/account", <br>&nbsp&nbsp"tableName":"reference.account",<br>&nbsp&nbsp"sqlTableName":"dbo.reference_account}}<code/>|
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

from datetime import datetime
from pyspark.sql.types import StructType, StructField, StringType, FloatType, IntegerType

# COMMAND ----------

# DBTITLE 1,Load Common Libraries
# MAGIC %run ../lib/common

# COMMAND ----------

# DBTITLE 1,Create raw notebook widgets
get_raw_notebook_widgets()

# COMMAND ----------

# DBTITLE 1,Get Notebook parameters
parameters = get_parameters()

# COMMAND ----------

# DBTITLE 1,Column Definition
schema_definition = StructType([
    StructField("Order", IntegerType(), True),
    StructField("Account", StringType(), True)
])

# COMMAND ----------

# DBTITLE 1,Parameters
#get processed datetime
process_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# get Source parameters
input_path = parameters["Source"]["inputFilePath"]
sheet_name = parameters["Source"]["sheetName"]
data_address = parameters["Source"]["data_address"]
enableFileTracker = parameters["Source"]["enableFileTracker"]

# get Sink parameters
destination_path = parameters["Sink"]["sink"]["outputFilePath"]
destination_table_name = parameters["Sink"]["sink"]["tableName"]

db_name = destination_table_name.split(".")[0]

# COMMAND ----------

# DBTITLE 1,Read CSV
# Intitate the reader class
excel_reader = read_excel(
    processDatetime = process_datetime
)

# Read all the dataframes
df = excel_reader.read(
    input_path
    , schema_definition
    , sheet_name
    , data_address
    , checkHeader = True
    , enableFileTracker = enableFileTracker
)

# Get total message count
df_message_count = df.count()

# COMMAND ----------

# DBTITLE 1,Processing
field_names = extract_field_names(schema_definition)

# Drop rows where all specified columns are null
df = df.dropna(how='all', subset=field_names)

# remove invalid characters 
df = remove_spaces_invalid_characters_in_column_names(df)

# COMMAND ----------

# DBTITLE 1,Write to Delta
record_count = write_delta(df, destination_path, mode="overwrite", partitionColumns=[])

#create database if not exist
create_database_if_not_exist(db_name)

# create table if not exist
create_table_if_not_exist(destination_table_name, destination_path)

# COMMAND ----------

# DBTITLE 1,Write to SQL DB
# Read entire dataframe
total_df = spark.table(destination_table_name)

# sql db table names
sql_table_name = parameters["Sink"]["sink"]["sqlTableName"]

# Write to sql server db
write_df_to_sql_server(total_df, sql_table_name, mode = "overwrite")

# COMMAND ----------

# DBTITLE 1,Logging
# Get metadata for all files read and processed
metadata_per_file = generate_metadata_json_per_file(df, process_datetime)

#Intiate logger class
logger = ProcessedFilesLogger(processDatetime = process_datetime)

# Log processed files to file tracker
logger.log_file_processed(metadata_per_file)

# COMMAND ----------

# DBTITLE 1,Exit Notebook
valuesToReturn = {
  "delta_rows_inserted": record_count, 
  "message_count":df_message_count,
  "sql_rows_inserted":total_df.count()
}

dbutils.notebook.exit(valuesToReturn)
