
# Adding Images to Markdown Files in Sphinx

This guide provides instructions on how to include images in your Markdown files when using Sphinx for documentation. Following these steps will help you enhance your documentation with visual elements.

## Prerequisites

Ensure that Sphinx along with the MyST Parser is installed in your project. MyST Parser allows Sphinx to interpret Markdown files.

## Step 1: Prepare Your Images

Before you can add images to your Markdown files, you need to ensure that your images are in a supported format (e.g., JPEG, PNG) and are placed in an accessible directory within your Sphinx project.

### Recommended Structure

- **Organize Images**: Place all images in a dedicated directory within your documentation source directory, typically `docs/source/_static/`, to keep your project organized.

## Step 2: Syntax for Adding Images

To include an image in a Markdown file, you use the following syntax:

```markdown
![Alt text](path/to/image.png "Optional title")
```

- **Alt text**: Describes the image; important for accessibility and SEO.
- **Path**: Relative or absolute path to the image file.
- **Optional title**: Displayed as a tooltip when the mouse hovers over the image.

## Step 3: Reference Images in Markdown

When adding images to your Markdown files, use paths relative to the location of the Markdown file within your project. Here’s an example of how to include an image:

```markdown
![Sphinx Logo](../_static/sphinx-logo.png "Sphinx Documentation Generator")
```

## Step 4: Build Your Documentation

After adding your images, you need to build your documentation to see the changes:

```bash
make html
```

This command will generate the HTML version of your documentation and include the images where you have placed them in your Markdown files.

## Step 5: Verify the Output

- **Check the HTML Output**: Open the `index.html` file located in `_build/html` with a web browser to ensure that your images are correctly displayed.
- **Adjust Image Paths if Necessary**: If images do not appear, check their paths for accuracy and ensure that the image files are in the correct directories.

## Conclusion

Adding images to your Sphinx documentation can significantly enhance the reader's understanding and engagement. By following these steps, you can effectively integrate visual content into your Markdown-based documentation.
