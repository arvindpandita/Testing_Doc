Git Workflow Documentation
=============================

Here you will find comprehensive documentation on using Git for your version control needs. This resource is designed to guide you through setting up, configuring, and maintaining your Git repositories, providing detailed insights into effective version control practices. 

.. toctree::
   :maxdepth: 2

   
   branch_creation_guide
   git_merge_guide
