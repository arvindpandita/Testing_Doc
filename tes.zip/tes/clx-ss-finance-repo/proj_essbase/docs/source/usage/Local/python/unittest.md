# Enable Unittest Framework in VS Code

## Enabling Unittest
- Set `true` for `python.unitTest.unittestEnabled` in settings.
- Ensure other test frameworks are set to `false`.

## Configuration Options
- **Test Discovery Pattern**: Default is `test*.py`. Modify in `settings.json` to `"-p", "test_*.py"`.
- **Verbosity**: Default level is 'v'. Change in `settings.json` as needed.
- **Start Directory**: Defaults to project root. Configure with `"-s", "./proj_essbase/tests"` in `settings.json`.
- **Fail Fast**: Stops on first error/failure. Enable with `"-f"` in `settings.json`.

## Running and Debugging Tests
- VS Code recognizes Python tests automatically.
- Run tests via "Run Tests" icon in the status bar.
- Debug by clicking "Run Test" above test method in code.

## Additional Resources
- For detailed instructions: [Testing Python in Visual Studio Code](https://code.visualstudio.com/docs/python/testing)
- Additional information: [Python Unit Testing With VS Code – Real Python](https://realpython.com/python-testing/)
- More on configurations: [Python in Visual Studio Code - unittest](https://donjayamanne.github.io/pythonVSCodeDocs/docs/unittests_unittest-framework/)

## Accessing `settings.json` in VS Code

### Through the Command Palette
1. **Open Command Palette**:
   - Press `Ctrl+Shift+P` (Windows/Linux) or `Cmd+Shift+P` (macOS).
2. **Open Settings (JSON)**:
   - Type `Preferences: Open Settings (JSON)` and select it to open `settings.json`.

### Via the Settings Menu
1. **Open Settings**:
   - Click the gear icon in the lower-left corner and select 'Settings'.
2. **Switch to JSON View**:
   - In the top right corner of the Settings tab, click the icon that looks like a page with an arrow. This opens `settings.json`.


```