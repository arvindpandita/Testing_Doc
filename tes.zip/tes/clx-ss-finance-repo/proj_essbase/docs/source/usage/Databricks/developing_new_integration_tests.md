# Developing New Integration Tests

## Introduction
This document outlines the process for developing and running new integration tests within the Databricks workspace.

## Navigating to the Test Folder
Access the testing notebooks and required resources at:
\```
clx-ss-finance-repo/proj_essbase/proj_essbase/databricks/notebooks/tests
\```

### Python Notebooks

#### Base
Contains the `BaseTesting` class which serves as a shared foundation among all integration testing subclasses. This class provides common setup and teardown routines, making the development of specific tests more streamlined and consistent.

**BaseTesting Class Explanation:**


### Python Notebooks

#### Base
Contains the `BaseTesting` class which serves as a shared foundation among all integration testing subclasses. This class provides common setup and teardown routines, making the development of specific tests more streamlined and consistent.

**BaseTesting Class Explanation:**

```python

import unittest
from pyspark.sql import SparkSession
from datetime import datetime

class BaseTesting(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        # Initialize Spark session for testing
        cls.spark = SparkSession.builder.appName("IntegrationTests").getOrCreate()

        # Setup JDBC connection properties for interacting with SQL databases
        cls.jdbcUrl = "jdbc:sqlserver://sql-ssefin-selfserv01.database.windows.net:1433;database=SQLDB-SSEFIN-SELFSERV01;"
        cls.connectionProperties = {
            "user": "SSEDATA_RW",
            "password": dbutils.secrets.get(scope="KV-SSE-SCOPE", key="KV-SSEDATA"),
            "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
        }

        # Capture the current timestamp for file naming or logging
        cls.curr_timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
  
    @classmethod
    def tearDownClass(cls):
        # Clean up any files created during tests in the designated output path
        files = dbutils.fs.ls(cls.temp_output_path)
        for file in files:
            dbutils.fs.rm(file.path, recurse=True)

        # Remove the test output directory after tests complete
        dbutils.fs.rm(cls.temp_output_path, recurse=True)
```

- **`setUpClass`**: Initializes resources like a Spark session and sets up SQL connection properties required across all integration tests.
- **`tearDownClass`**: Ensures removal of any files and directories created during the testing process, preventing data clutter and ensuring each test starts with a clean state.

#### Additional Notebooks

- **run_all_test_notebooks**: Executes all available integration tests loaded onto the cluster.
- **run_single_test_notebook**: Facilitates the execution of a single integration test notebook; particularly useful during the development of specific data pipeline testing notebooks.
- **testing_notebooks_list**: Lists all active integration tests run and loaded onto the cluster when executing the `run_all_test_notebooks`.

### Folders

- **Driver**: Contains all integration tests for driver notebooks.
- **Essbase**: Hosts all integration tests for Essbase notebooks.
- **Reference**: Includes all integration testing notebooks for reference notebooks.

## Adding a New Integration Testing Notebook

1. **Repository Navigation**: Ensure you are on the correct branch where changes should be made.
2. **Create a Notebook**: Navigate to the respective testing folder in Databricks and create a new Python notebook (e.g., in the Driver folder).
   - Import the base class at the beginning of your notebook:
     
    ```python

    %run ../base
    ```

   - Create a new class following the naming convention: `<notebook_name>_IntegrationTest`. Example:
    
    ```python

    class driver_actuals_bucket_curated_IntegrationTest:
        pass
    ```

## Setting Up Test Cases

- **setUpClass** and **tearDownClass**: Define these methods to set up and tear down test configurations.
- **Naming Convention**: Test methods should start with `test_` followed by the notebook name, the aspect being tested, and the test focus, e.g., `test_driver_actuals_bucket_curated_table_records_inserted_count`.

### Common Test Cases Include:

- Record counts inserted into delta tables.
- Message counts verification.
- Record insertion checks into SQL tables.

## Creating a Folder in ADLS for Sample Testing Data

### Data Storage Account Information:

- **Subscription**: AZ-SSE-FIN-SUB
- **Resource Group**: RG-SSEFIN-DWSDEV01
- **Storage**: stssefinselfserv01
- **Container Name**: (Specify container name)
- **Folder Path**: `/mnt/clx-datalake/finance/testing/`

### Mount Name in Databricks:

- **Mount Name**: clx-datalake

Navigate to the test folder in ADLS storage and create the respective folder for your test data. Ensure the test data is copied to this new folder and the input file path in your testing notebook is updated accordingly.

### Running and Adding a Testing Notebook

- **Single Test Execution**: After developing a new integration testing notebook, run it individually using `run_single_test_notebook`.
- **Adding to Test List**: Once the integration testing is verified, add the notebook to the `testing_notebooks_list`.

### Running Full Integration Testing

1. **Execute All Tests**: Run the `run_all_test_notebooks` to ensure no new changes disrupt existing functionality.
2. **Document Results**: If all tests pass, document the results, and attach them to the relevant user story for review.
