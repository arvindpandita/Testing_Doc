# Setting Up and Connecting a Repo in Databricks Workspace to GitHub

## Step 1: Access Workspace
- Open your **Databricks Workspace**.
- Click on the "Workspace" button located in the top right corner of the page.

## Step 2: Select Repo Workspace
- Click on "Repos" in the sidebar menu.
- Select your Databricks account from the list of available repository workspaces.

## Step 3: Create a New Repository
- Click on the "Create" button, located in the top right corner of your page.
- Select "Create Repo" from the dropdown menu.

## Step 4: Link to GitHub Repository
- Go to your GitHub repository.
  - To copy the HTTPS URL of your repository: Navigate to the repository on GitHub, click on the "Clone" button, and then copy the HTTPS URL.
- Back in Databricks, paste this URL into the "Git Repository URL" box on the "Create Repo" page.
  - The remaining fields will be automatically populated once you paste the URL.
- Click "Create Repo" to finalize the setup.

## Additional Notes
- Ensure that your GitHub repository is ready and accessible before linking it with Databricks.
- If you encounter any authentication issues, check your GitHub settings for any required access tokens or permissions.

By following these steps, you will successfully connect your Databricks workspace to your GitHub repository, allowing for streamlined management and collaboration on your projects.
