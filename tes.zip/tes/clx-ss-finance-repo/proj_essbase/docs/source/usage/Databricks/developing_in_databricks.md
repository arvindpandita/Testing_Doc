# Developing in Databricks

This document outlines the steps required for developing and testing code in the Databricks environment. It emphasizes proper version control practices, thorough testing, and documenting changes related to specific user stories.

## Pre-Development Setup

### Ensure Current Branch is Synced
Before starting any new development work, it is crucial to ensure that you are working with the latest version of your current branch:
- Navigate to the "Repos" section within your Databricks workspace.
- Select your project repository and the branch you are working on.
- Sync the latest changes from your branch to ensure all updates are pulled into your Databricks workspace.

## Development Process

### Perform Your Task
- Carry out the coding tasks as required by your project. This could involve writing new code, fixing bugs, or making improvements to existing features.

## Testing

### Running Integration Tests
Before submitting your changes, a full integration test must be run to ensure the stability and functionality of the code:
- Navigate to the test folder located at `clx-ss-finance-repo/proj_essbase/proj_essbase/databricks/notebooks/tests`.
- Open the notebook titled `run_all_test_notebooks`.
- Attach the notebook to your cluster to utilize computational resources.
- Execute the notebook to run all included test scripts and validate the integration of new changes.

### Documenting Test Results
- Upon completion of the tests, take a screenshot of the test results.
- Attach this screenshot to the respective user story you are working on to provide evidence of the test completion and outcomes.

## Committing Changes

### Review and Commit Changes
After completing your development and testing:
- Click on the branch name located in the top right corner of your workspace.
- Review all tracked changes carefully to ensure no unintended changes are included.
- Add a commit message describing the changes you have made. Be specific and informative to provide context for the changes.

### Submit Your Changes
- Click the "Submit" button to commit your changes to the branch.
- Ensure that your commit is pushed to the remote repository to make your changes available to other team members.

## Conclusion

Following these steps will help maintain high standards of code quality and ensure that all changes are properly tested and documented before being integrated into the main project. This process helps in minimizing disruptions and maintaining a smooth workflow within your development team.
