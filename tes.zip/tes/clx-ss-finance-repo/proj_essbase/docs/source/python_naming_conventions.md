
# Python Project Naming Conventions and PEP 8 Guide

## Python File Naming Conventions

Adopting a good file naming convention in Python is crucial for readability, maintainability, and facilitating collaboration among developers. Here are some key points and best practices for naming Python files:

### 1. Use Lowercase Letters

- Python filenames should be all lowercase to avoid issues with case sensitivity on different operating systems.

### 2. Use Underscores for Readability

- Use underscores (`_`) to separate words in filenames for better readability. Example: `my_module.py`.

### 3. Keep Names Short and Descriptive

- Filenames should be concise yet descriptive to clearly indicate the file's purpose. Example: `email_parser.py`.

### 4. Avoid Special Characters

- Apart from underscores, avoid using special characters in filenames, such as hyphens (`-`), spaces, or characters special to shell environments.

### 5. Prefix for Private Modules

- Prefix filenames with an underscore (`_`) if they are meant to be used internally within a package. Example: `_internal_utils.py`.

### 6. Match Module Names with Class Names

- For files containing a single class, name the file similarly to the class name (converting CamelCase to snake_case). Example: `EmailParser` class should be in `email_parser.py`.

### 7. Script Naming

- For executable scripts, keep the names relevant to their functionality, even if they don't strictly follow the underscore convention.

### 8. Avoid Naming Files After Built-in and Standard Library Modules

- Do not name files in a way that shadows the names of built-in or standard library modules, like `json.py`.

### Example Filenames:

- `database_connection.py`
- `util_functions.py`
- `_private_module.py`
- `data_analysis.py`

Following these conventions ensures that your codebase remains clean, organized, and accessible to other developers.

## PEP 8 Naming Conventions Guide

This guide provides an overview of the naming conventions proposed by PEP 8, Python's official style guide, to ensure consistency and readability across Python projects.

### Overview

PEP 8 suggests specific naming patterns for various elements within a Python project, including variables, functions, classes, modules, constants, and more. Following these conventions improves the readability of your code and helps maintain a standard across Python projects.

### Naming Styles

- **snake_case**: Lowercase with words separated by underscores. Used for function names, variable names, and module names.
- **CamelCase**: First letter of each word capitalized, used for class names.
- **UPPERCASE**: All letters in uppercase, used for constants.

### Specific Conventions

#### Variables

- Use `snake_case` for variable names:
  ```python
  my_variable = 10
  ```

#### Functions

- Functions should also use `snake_case`:
  ```python
  def my_function():
      pass
  ```

#### Classes

- Class names should follow the `CamelCase` convention:
  ```python
  class MyClass:
      pass
  ```

#### Modules

- Module names should be short and use `snake_case`:
  ```python
  # In a file named my_module.py
  ```

#### Constants

- Constants defined at the global level should use `UPPERCASE`:
  ```python
  MAX_SIZE = 100
  ```

#### Method Names and Instance Variables

- Use `snake_case` for method names and instance variables:
  ```python
  class MyClass:
      def my_method(self):
          pass
      def set_value(self, value):
          self.my_value = value
  ```

#### Avoiding Clashes

- For internal use, prepend a single underscore (`_`) to indicate a non-public method or variable.
- To avoid naming conflicts with Python keywords, append a single underscore (`_`) to the name.

### Additional Tips

- Be descriptive with your naming without being verbose. Aim for clarity in your names.
- Avoid using names that are too generic or vague, such as `obj`, `data`, unless in a very localized context.

Adhering to these naming conventions as outlined in PEP 8 ensures your Python code is more accessible and maintainable, making it easier for others to read and contribute to.
