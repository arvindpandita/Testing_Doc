.. Finance Self-Service Essbase Temporary Pipeline documentation master file

Welcome to Finance Self-Service Essbase Temporary Pipeline's documentation!
===========================================================================

Project Overview
-----------------

This project is a comprehensive solution designed for processing and analyzing Profit & Loss (P&L) and driver data. It provides a flexible and robust pipeline for data integration, starting from raw inputs through to consumable outputs, ready for business intelligence tools like Power BI.

Getting Started Section
------------------------

To get started with this project, follow documents and steps included in the getting started section of the pipeline documentation. :

1. **Clone the Repository**: Use Git to clone the repository to your local environment - which should be completed at this time. 
2. **Install Dependencies**: Refer to the Installation section for guidance on setting up your environment.
3. **Configure the Environment**: Set any required environment variables and ensure the proper software is installed.

Installation Section
---------------------

To install the necessary dependencies for this project, please follow the documents listed in this section. 

Usage Section
--------------

Here's how to use the pipeline:

1. **Configure the Pipeline**: Customize the pipeline according to your data sources and processing requirements.
2. **Run the Pipeline**: Execute the pipeline to process the data, monitoring for errors or discrepancies.
3. **Push Data to Azure SQL Service**: Once processing is complete, deploy the final datasets to Azure SQL Service for Power BI dashboard consumption.

Notebook Documentation Section
--------------------------------

If the project includes databricks notebooks to layout the data processing and business logic processing. 

1. **Overview**: Describes the purpose of the notebook and the processing pipeline.
2. **Dependency**: Indicates if there are any dependencies for this notebook.
3. **Acceptance Criteria**: Specifies the criteria for verifying the success of the data processing. 
4. **Notebook Details**: Provides specific information about the notebook's paths, source and sink parameters, and integration testing setup.
5. **Additional Notes**: Offers extra context or guidance related to source files and storage locations.
6. **Documentation Update History**: Contains a table with a history of updates to the notebook's documentation, including dates, developers, story IDs, and comments.

Dashboard Integration
-----------------------

The processed data is designed to integrate seamlessly with Power BI dashboards. Ensure your Power BI setup is configured to connect with Azure SQL Service and use the relevant tables for visualization and reporting.

Troubleshooting
-----------------

If you encounter issues, consider the following:

- **Data Discrepancies**: Verify the raw data sources and their transformation logic in the pipeline.
- **Pipeline Errors**: Check error logs for specific issues and resolve them before re-running the pipeline.
- **Azure SQL Connection**: Ensure your Azure SQL Service configuration is correct and accessible from your environment.


Contents:
---------

.. toctree::
   :maxdepth: 2
   :caption: Getting Started

   introduction.md
   python_naming_conventions.md

.. toctree::
   :maxdepth: 2
   :caption: Installation

   
   installation/databricks/index
   installation/local/index

.. toctree::
   :maxdepth: 2
   :caption: Usage

   usage/databricks/index
   usage/local/index

.. toctree::
   :maxdepth: 2
   :caption: Notebook Documentation

   notebooks/essbase/index
   notebooks/driver/index



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
