# Project Essbase Folder Structure

This document describes the folder structure of the project. Each directory and file is outlined with a brief description of its purpose and contents.

## Root Directory

- `/docs`: Contains documentation files for the project.
- `/proj_essbase`: The main project package where the source code resides.
- `/tests`: Unit and integration tests for the project.
- `requirements.txt`: Lists all the dependencies required for the project.
- `setup.py`: Setup script for the package distribution.

### Docs Directory

- `/docs/build`: Compiled files (e.g., HTML, PDF) generated from documentation source files - currently not being used. 
- `/docs/source`: Source files for documentation, written in Markdown.

### proj_essbase Directory

- `/proj_essbase/__init__.py`: Initializes the Python package.
- `/proj_essbase/proj_essbase/__init__.py`: Main project module is can be found here

### Tests Directory

- `/tests/`: Tests for `proj_essbase module`.

## Top-Level Files

- `requirements.txt`: Required Python libraries for the project, installable via `pip install -r requirements.txt`.
- `setup.py`: Contains package and distribution information, used for generating the distributable package of the project.

## Additional Information

- This structure is a starting point and can be adapted based on the project's growth and specific needs.
- Regularly updating the documentation to reflect changes in the project structure is recommended.
