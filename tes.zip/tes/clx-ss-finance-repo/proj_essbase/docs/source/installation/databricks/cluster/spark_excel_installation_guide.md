
# Installing the Spark-Excel Library on a Databricks Cluster

This guide describes the steps to install the `com.crealytics:spark-excel_2.12:0.13.5` Maven library onto your Databricks cluster. This library allows for efficient reading and writing of Excel files using Apache Spark.

## Prerequisites

Ensure you have:
- An active Databricks account.
- A running Databricks cluster with administrator or library installation permissions.

## Step 1: Navigate to Your Cluster

1. **Log in to Databricks**: Access your Databricks workspace by entering your credentials at your workspace URL.
2. **Open the Compute Tab**: Once logged in, click on **Compute** in the sidebar to view a list of your available clusters.
3. **Select Your Cluster**: Click on the cluster where you want to install the Spark-Excel library. Make sure the cluster is running; if not, start it by clicking on **Start**.

## Step 2: Install the Spark-Excel Library

Follow these steps to install the library:

1. **Access Libraries**: Click on **Libraries** under the Common Tasks or directly from the cluster detail page.
2. **Install New Library**: Click on **Install New** to add a new library.
3. **Choose Library Type**: Select **Maven** from the library source options.
4. **Specify Maven Coordinates**: In the Maven coordinate field, input the following:
   ```
   com.crealytics:spark-excel_2.12:0.13.5
   ```
5. **Search and Select the Library**: Click **Search** to find the library, then select it from the search results.
6. **Install the Library**: Click **Install** to add the library to your cluster.

## Step 3: Verify the Installation

To ensure the library is installed correctly:

1. **Check Installation Status**: Monitor the library status in the Libraries tab of your cluster. A successful installation will show the library as 'Installed'.
2. **Test the Library**: Open a notebook linked to your cluster and try importing the library to verify it:
   ```python
   import com.crealytics.spark.excel
   ```

## Conclusion

You have successfully installed the `com.crealytics:spark-excel_2.12:0.13.5` library on your Databricks cluster. This library is now ready to be used for reading and writing Excel files in your data processing workflows. For more advanced usage scenarios and troubleshooting, you can refer to the [Databricks documentation on libraries](https://docs.databricks.com/libraries/index.html) and the [GitHub page for the spark-excel library](https://github.com/crealytics/spark-excel).
