
# Azure CLI Installation Guide for Windows

This guide provides detailed instructions on how to install the Azure Command-Line Interface (CLI) on Windows. The Azure CLI is an essential tool for managing Azure resources directly from the command-line interface.

## Prerequisites

Before installing the Azure CLI, ensure that your Windows system meets the following requirements:
- **Operating System**: Windows 10 or later
- **Permissions**: Administrative access is required for installation.

## Installation Steps

### Step 1: Download the Installer
1. Visit the official Azure CLI download page: [Install Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=azure-cli)
2. Download the MSI installer for Windows.

### Step 2: Run the Installer
1. Run the downloaded MSI file to start the installation process.
2. Follow the on-screen instructions to complete the installation, choosing the default options or customizing as needed.

### Step 3: Verify the Installation
1. Open Command Prompt.
2. Type `az --version` to ensure the CLI is installed correctly. This command should display the version of the Azure CLI installed on your system.

## Conclusion

With the Azure CLI installed, you can now manage your Azure resources directly from your Windows command line. To start using the Azure CLI, it's recommended to run `az login` to log in to your Azure account. This will authenticate your device and allow you to execute commands that interact with your Azure services.

For more detailed instructions and troubleshooting, visit the official Azure CLI documentation page: [Azure CLI Documentation](https://docs.microsoft.com/en-us/cli/azure/).
