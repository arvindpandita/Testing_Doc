Local Installation Guide
==========================

Here are the detailed local installation instructions, tailored to guide you through setting up your environment efficiently.

.. toctree::
   :maxdepth: 2

 
   git/index
   python/index
   sphinx/index
   spark/index
   azure_tools/index

