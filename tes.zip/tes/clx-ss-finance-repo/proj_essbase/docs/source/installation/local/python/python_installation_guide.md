# Python Installation Guide

This document provides detailed instructions for installing Python and various Python libraries essential for development and data analysis. Follow these steps to ensure a successful installation.

## Installing Python

Python is a powerful, versatile programming language used widely in web development, data science, artificial intelligence, and more. Below are the steps to install Python on your system.

### Step 1: Download Python

1. **Visit the Official Python Website**: Go to [python.org](https://www.python.org/downloads/).
2. **Select the Version**: Choose the latest version of Python or a version that your projects specifically require.
3. **Download for Your Operating System**: Click on the download link for your operating system (Windows, macOS, or Linux/UNIX).

### Step 2: Install Python

1. **Run the Installer**: Open the downloaded installer. Windows users should ensure to check the box that says "Add Python to PATH" before clicking "Install Now."
2. **Follow the Setup Wizard**: The installer will guide you through the necessary steps. On macOS and Linux, you might use the terminal for installation.

### Step 3: Verify Installation

After installation, verify that Python is correctly installed by opening your command line (terminal) and running:

```bash
python --version
