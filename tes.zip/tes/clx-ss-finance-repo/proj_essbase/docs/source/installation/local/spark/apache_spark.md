# Apache Spark Installation

## Prerequisites

1. Java: Spark requires Java. You can download and install it from the official [Oracle website](https://www.oracle.com/java/technologies/javase-downloads.html) or adopt OpenJDK.
2. Python : If you're planning to use PySpark, install Python from [Python's website](https://www.python.org/).
3. Scala (Optional): To use Spark with Scala, install it from the [Scala website](https://www.scala-lang.org/download/).

## Installing Spark

1. Download Spark:
> * Visit the [official Apache Spark website](https://spark.apache.org/downloads.html).
> * Choose a Spark release, a package type, and download Spark as a .tgz file.

2. Download Hadoop:

> * Visit [Apache Hadoop's download page](https://hadoop.apache.org/releases.html) and download the binary.
> * Spark uses Hadoop's libraries for distributed data storage, so it's necessary even if you're not using Hadoop's distributed data storage.

3. Extract Files:

> * Extract the Spark and Hadoop binaries to a location of your choice, for instance, C:\Spark and C:\Hadoop respectively.

## Configuring Environment Variables

1. Configure System Variables:

> * Open System Properties → Advanced → Environment Variables.
> * Add/edit the following system variables:
> > * JAVA_HOME: Path to your Java installation, e.g., C:\Program Files\Java\jdk-17.
> > * HADOOP_HOME: Path where you extracted Hadoop, e.g., C:\Hadoop.
> > * SPARK_HOME: Path where you extracted Spark, e.g., C:\Spark.
> > * Edit Path variable, append %JAVA_HOME%\bin, %HADOOP_HOME%\bin, and %SPARK_HOME%\bin.

2. Configure Spark:

> * Go to your Spark directory and navigate to conf.
> * Copy spark-env.sh.template to spark-env.sh and edit it to include:
> > * javascript

> > `SPARK_DIST_CLASSPATH=$(C:\Hadoop\bin\hadoop classpath)`
> > * This may vary slightly based on your installation directories and shell.

## Running Spark

> * Run Spark Shell:

> > * Open a Command Prompt or PowerShell.
> > * Type spark-shell to start the Scala shell, or pyspark to start the Python shell.
> > * You should see Spark initializing and once ready, you can start typing Spark commands.

> * Run Spark Jobs:

> > * Use spark-submit to run Spark jobs. Syntax can be found in Spark's documentation and typically looks like:
bash
> > `spark-submit --class org.apache.spark.examples.SparkPi --master local[2] path\to\your\spark\examples\jar 1000`
> > * Adjust --class to point to your job's entry point, --master to your cluster URL, and the last parameter to your job’s jar file.

## Note:

> * Ensure you troubleshoot any path issues or library dependencies issues by closely examining error messages.
> * Depending on your version and use case (e.g., integrating with Jupyter notebooks), additional steps might be required.
> * Visit the [Apache Spark website](https://spark.apache.org/docs/latest/) for documentation and more detailed setup guides.



