
# PySpark Installation Guide

This document provides detailed instructions on how to install PySpark, the Python API for Apache Spark, on your local machine. PySpark enables you to leverage the powerful data processing capabilities of Apache Spark using Python.

## Prerequisites

Before you install PySpark, ensure that you have the following installed on your system:
- **Python**: PySpark requires Python to be installed. Versions 3.6 through 3.8 are officially supported.
- **Java**: Apache Spark requires Java to be installed. Java 8 or 11 is recommended.
- **pip**: Python's package installer, which is typically included with your Python installation.

## Step 1: Verify Java Installation

Apache Spark requires Java. Verify that Java is installed by running the following command in your command prompt or terminal:

```bash
java -version
```

If Java is not installed, download and install it from [Oracle's website](https://www.oracle.com/java/technologies/javase-jdk11-downloads.html) or your preferred source.

## Step 2: Install PySpark

Once Java is confirmed or installed, you can install PySpark using pip. Open your command prompt or terminal and run:

```bash
pip install pyspark
```

## Step 3: Verify PySpark Installation

After installation, you can verify that PySpark is installed correctly by starting a Python interpreter and importing PySpark:

```python
python
>>> import pyspark
```

If no errors appear, PySpark is installed correctly.

## Step 4: Configure Environment Variables (Optional)

To use PySpark more effectively, you might need to configure your environment variables:

- **JAVA_HOME**: Points to the directory where Java is installed.
- **SPARK_HOME**: Points to the directory where Spark is installed if you installed a standalone Spark distribution.
- **PYTHONPATH**: May need to include paths to PySpark and Py4J (which comes with PySpark).

Here's an example of setting these on a Unix-like system:

```bash
export JAVA_HOME=/path/to/java
export SPARK_HOME=/path/to/spark
export PYTHONPATH=$SPARK_HOME/python:$SPARK_HOME/python/lib/py4j-0.10.x-src.zip:$PYTHONPATH
```

Adjust the paths according to your installation details and operating system.

## Conclusion

You have successfully installed PySpark on your local machine. You can now begin developing applications with Apache Spark and Python or performing data analysis tasks efficiently. For more advanced configurations and usage scenarios, refer to the [official PySpark documentation](https://spark.apache.org/docs/latest/api/python/index.html).
