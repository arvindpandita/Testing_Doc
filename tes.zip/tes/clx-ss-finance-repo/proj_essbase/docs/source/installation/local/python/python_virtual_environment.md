# Setting Up a Python Virtual Environment

## 1. Install Virtualenv (if not already installed)

```bash
pip install virtualenv
```

### Create a Virtual Environment:
Navigate to your project directory and run:
```bash
virtualenv venv
```
`venv` is the name of the virtual environment folder.

### Activate the Virtual Environment:
- On Windows:
  ```bash
  .\venv\Scripts\activate
  ```

## 2. Using `requirements.txt` in Development

- To ensure that all dependencies listed in `requirements.txt` are installed:
  ```bash
  pip install -r requirements.txt
  ```

## 3. Deactivating the Virtual Environment

Once you're done working in the virtual environment:
```bash
deactivate
```

### Best Practices

- Keep Your `requirements.txt` Updated:  Whenever you install a new package, remember to update requirements.txt using pip freeze > requirements.txt.
- Documentation: Document the purpose of each dependency in your requirements.txt for clarity and maintainability.

### Troubleshooting

- Package Installation Errors: If you encounter errors while installing packages, check for compatibility issues and ensure you're using the correct version of Python.
- Virtual Environment Not Activating: Ensure you are in the correct directory and the virtual environment has been created properly.

