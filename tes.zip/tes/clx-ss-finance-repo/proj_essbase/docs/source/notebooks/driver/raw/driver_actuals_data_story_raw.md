# actuals_data_story_raw Notebook

## Overview

This notebook is designed to process actual raw data from the landing zone to the raw zone. The data is coming from essbase tables. 

Upon initiation, the data is ingested into a PySpark DataFrame. This step ensures robust handling and manipulation of the dataset. 
Subsequent to the data ingestion, defined schema is applied to the DataFrame, ensuring data integrity and structure conformity.

The data is then loaded to the Delta table. In the final stage of the process, all the contents of the Delta table are synchronized with an Azure SQL table. 
This action signifies the completion of the data processing pipeline, thereby making the transformed data readily available for further analysis or operations in the Azure SQL environment.

## Dependency 

None 

## Acceptance Criteria

The number of row counts from source files should match the raw table.

## Notebook Details

| Name | Value |
| --------------- | --------------- |
| Notebook Path   | `proj_essbase/proj_essbase/databricks/notebooks/driver/driver_actuals_data_story_raw.py`   |
| Integration Notebook Path |  `proj_essbase/proj_essbase/databricks/notebooks/tests/driver/driver_actuals_story_raw_IntegrationTest.py`  |
| Source Parameters |  `{"inputFilePath":"/mnt/clx-datalake/finance/landing/driver/actuals/story", "enableFileTracker": "True" }`  |
| Sink Parameters |  `{"sink":{"outputFilePath":"/mnt/clx-datalake/finance/raw/driver/actuals/story", "tableName":"raw.driver_actuals_story", "sqlTableName":"dbo.raw_driver_actuals_story"}}`  |

## Additional Notes

* Incoming source files should contain a similar structure
* Incoming files are placed in ADLS storage location as needed by data owners

## Documentation Update History

| Date | Developer|Story ID | Comment |
| --------------- | --------------- | --------------- | --------------- |
| 01/31/2024  | Debasish Chakraborty  | 72306 | Added initial documentaton for notebook |
